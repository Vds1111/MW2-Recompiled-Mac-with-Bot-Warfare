# Getting into a level

What the runtime provides between boot and a playable level. The multiplayer's
additional needs (network link, sessions) are in [multiplayer.md](multiplayer.md).

## Game data

The title reads its fastfiles from the game root (`mw2/game` for a developer
build; see [building.md](building.md)). File paths resolve case-insensitively
onto that one flat directory.

| files | status |
|---|---|
| `.ff` fastfiles, `.pak` image archives, `.bik` Bink movies | all of them are extracted, by `build.sh` from the ISO or by the launcher (`launcher/`) |

Every fastfile is needed, not only the current level's: a zone whose file is
missing makes the title report a dirty disc and fail, and the multiplayer picks
its own zones.

## Movies

Bink is linked into the title (its own `BINK` section) and decodes on the CPU,
on two threads of its own per movie, and its sound reaches the output with the
rest of the title's. Nothing in the runtime is specific to it.

The campaign plays `IW_logo` and `legal` at boot, and a level's briefing while
the level loads: `video/cin_levels.txt` in `common.ff` names it, `<map>_load`.
When the load finishes, `UI_SetActiveMenu` opens the `pregame` menu, whose item
`press_to_skip` runs `uiScript playerstart` on A, and the level starts; it also
starts when the briefing ends. With `ui_autoContinue` set it starts as soon as
the load finishes, which a scripted run wants:

    MW2_CONSOLE="1:set ui_autoContinue 1;2:map trainer"

With a movie's file missing the title logs it, skips it, and the level starts
when it is loaded.

## Loading a level from the command line

`MW2_CONSOLE` queues commands into the engine's own console command buffer,
which is the shortest path to a level:

    MW2_CONSOLE="30:map trainer"            # one command at 30 s
    MW2_CONSOLE="30:map af_caves;45:god"    # several, separated by ';'

The time is wall-clock seconds since the runtime started (the clock
`MW2_INPUT_SCRIPT` uses). Only `;` separates entries and only the first `:`
separates the time, so a command may contain spaces. It is kept in release
builds.

`runtime/console.cpp` calls the title's `Cbuf_AddText` (`T_Cbuf_AddText` in
[`runtime/title.h`](../runtime/title.h)) from `XamInputGetState`, which the title
polls once a frame on its main thread, so a live guest context is always
available. `Cbuf_AddText` copies its text, so the string only has to outlive the
call: it is written 256 bytes below the guest stack pointer, and the call is
made with the stack pointer moved further down so the callee's frame cannot
overlap it. The whole guest context is saved and restored around the call,
because the guest is in the middle of a kernel import. One command is queued per
poll; a command longer than 192 bytes is refused.

Level names are the fastfile names: `trainer` is S.S.D.D., the first campaign
mission; `af_caves` is "Just Like Old Times". In the campaign, `setviewpos x y
z yaw pitch` places the player (`F9` logs the current `viewpos`); the
multiplayer refuses it ([switches.md](switches.md)).

## Controllers

`runtime/kernel/input.cpp` backs `XamInputGetState`, `XamInputGetCapabilities`
and `XamInputSetState` with SDL3 gamepads; controller *n* is SDL's *n*-th
gamepad, looked for again once a second while absent. Capabilities report a
wired 360 pad: every control at full range and both motors at `0xFFFF`.

`XamInputSetState(user, flags, vibration)` takes the motor speeds from the third
argument (`flags` is unused). The left motor is the heavy low-frequency one,
SDL's first rumble argument. A 360 motor keeps its speed until the next call, so
each rumble is given SDL's longest duration (`0xFFFF` ms); a duration of zero
would also stop SDL resending the rumble to pads that let one lapse. The log
names the first rumble per controller, or that the pad cannot rumble.

The title sends zero speeds unless the profile's rumble option is on (byte 67
of its per-controller profile record, on by default) and the local player is in
play: while spectating (`pm_type` 5) or following another player it clears every
rumble each frame. A headless test has to spawn first (`MW2_WALK_PATH`) and then
fire (`MW2_INPUT_SCRIPT`).

## Signing in

Every player is a profile of this machine: a line of `saves/profiles.txt`,
twelve hexadecimal digits -- the number the title knows him by -- and a name
(`runtime/signin.cpp`).

The first controller's profile is signed in from the start. It is made the
first time the game runs, named after the login (or `MW2_NAME`), and is the
same every run: the file's `first` line names it, and the launcher's PROFILES
screen puts another there. The online service is not who the player is. Steam
gives him the name other players see and brings his friends; the lan gives
him nothing but the network. His rank is the profile's, in files on this
machine ([saves.md](saves.md)), whichever service he plays through.

The file's `machine` line is a hash of the machine's own id (`MachineGuid`,
`/etc/machine-id`). Read on another machine, where a copied game folder ends
up, every profile gets a new number and what was kept under the old one is
renamed (`kernel::MovePlayerData`): two machines playing as one player is two
of the same player in a match, and the title drops the host when a player it
already has connects again.

Versions before profiles knew the first player by the service's own number,
Steam's account or a hash of the lan's name. The rank kept under that number
is renamed to the profile's the first time it plays (`Service::FormerAccount`,
`InheritOfflineStats` in `kernel/xam.cpp`).

Nobody is at the other controllers until the sign-in screen puts someone
there, and that is not kept between runs.
It is the console's screen, which a title asks for with `XamShowSigninUI` and
never draws: the multiplayer asks from SIGN IN PROFILE and CHANGE PROFILE in
split screen, and when a controller nobody is signed in at chooses SYSTEM
LINK. The Guide button opens it too, as on the console, or Back and Start
together where the system keeps that button.

The console's screen also signs a guest in beside a player on Live. This one
does not: the title's split screen is offline only, and its system link takes
one player a copy.

It lists the profiles of this machine that are not already playing, and "New
profile", which makes "Player 2" or the next free number. A profile is signed in
locally (state 1) under the offline XUID `0xE000` over those digits; the title
names its stats by that XUID and its settings are `profile_<digits>.bin`
([saves.md](saves.md)). The launcher's PROFILES screen renames one, and puts one
at the first controller.

The screen opens for the controller pressed last, since the call does not say
which. While it is open the title reads every controller as idle and hears
`XN_SYS_UI`; a choice is `XN_SYS_SIGNINCHANGED` with a bit per signed-in
controller, on which the title reads the new profile, stopping for a second.

The picture is drawn on the CPU with the launcher's fonts and laid over the
middle of the frame by the presenter, as a copy: it is opaque.
`MW2_DUMP_FRAMES` writes each state of it as `signin_<n>.ppm`.

## The save-device prompt

The campaign asks which storage device to save to until each controller has
one. `Memcard_InitializeSystem` keeps the choice in a table of one word per
controller, and zero means "not chosen". On the console the choice lives in the
profile and is made once; here the table starts empty every launch. The runtime
hooks `Memcard_InitializeSystem` (`runtime/kernel/content.cpp`) and, after it
returns, writes the hard disk's device id into every empty slot, so the prompt
does not appear. `MW2_NO_AUTO_SAVE_DEVICE=1` leaves the prompt to the title.
The table's address is known only for the campaign (`T_DATA_DeviceTable` is zero
in the multiplayer build). Saves themselves are in [saves.md](saves.md).

## What the level load relies on

These kernel and translation details are not visible in the menus, and the
first level load fails without them.

**Processor numbers.** The title pins its threads with `KeSetAffinityThread` (and
the top byte of the thread creation flags), a one-bit mask over the console's
six hardware threads. The runtime stores the chosen processor in
`KPCR.CurrentProcessorNumber` (offset 268), because the engine reads it: the
renderer's command-buffer jobs are admitted only on processors 1 and 2, whose
per-processor contexts they write into, and XAudio2's mixer threads wait on each
other by processor number. With every thread reporting 0, the first frame of a
level never finishes. Threads pinned to one processor run concurrently here,
which the console never does, so per-processor data is a place to look when
something races.

**Two windows onto physical memory.** D3D9 writes its recorded command chunks
through `0xA0000000` and reads them back through `0xC0000000`; both windows are
mapped over the same pages ([runtime.md](runtime.md)).

**Packed vertex formats.** Level geometry is packed and unpacked on the CPU
(skinning among others) with the VMX128 `vpkd3d128`/`vupkd3d128` instructions,
in formats upstream XenonRecomp does not implement.
`patches/xenonrecomp-mw2.patch` adds type 2 -- three 10-bit signed normalised
components with `w` in the top two bits, laid out like D3DCOLOR; like that case
the instruction only moves each field into the mantissa of `3.0f`, and the
caller's multiply-add by `(511 * 2^-22, -3.0)` finishes it, which is why full
scale is 511 -- and the `float16_2` pack.

## Field of view

`MW2_FOV` (`runtime/field_of_view.cpp`) widens the view. The number is counted
as the title's own `cg_fov` is: the angle across a 4:3 picture, 65 by default.
The title makes the 16:9 picture as tall as the 4:3 one and wider (the angle's
tangent times 0.75 is the half height, and that times the picture's shape the
half width), so 65 is 81 degrees across the screen, 90 is 106 and 120 is 133.

Neither of the title's two settings can carry the player's choice, because its
scripts write both. `cg_fov` is set to 65 at every multiplayer spawn
(`_playerlogic.gsc`) and walked through other angles by the campaign's climbs
and cinematics (`_climb.gsc`, `lerp_fov_overtime` in `_utility.gsc`);
`cg_fovScale` is written at every level load and every multiplayer connect,
0.75 in split screen and 1 otherwise (`_load.gsc`, `_playerlogic.gsc`), and
walked by `lerp_fovscale_overtime`. A value put in either lasts until the next
script that writes it.

So the settings are left alone, and the title is made to see `cg_fovScale` as
what its scripts last wrote times `MW2_FOV / 65`, in the two functions that
read it:

| | campaign | multiplayer | |
|---|---|---|---|
| `T_CG_ViewFov` | `8210FCD8` | `8215B9A8` | the angle a client's view is drawn with: `cg_fov`, or the weapon's while aiming (blended in as the sight comes up), or a turret's or a kill camera's; times `cg_fovScale`; held between `cg_fovMin` and 170 |
| `T_CG_CullZoom` | `8210FF80` | `8215BC28` | the zoom the distance culls take from that view, divided by `cg_fovScale` so the scale does not bring them nearer |

Each hook scales the function's result: the first multiplies it and holds it
under the title's 170 again, the second divides it. That is the result the
function would have had with the scale in the setting, except for a view the
title was already holding at one of its bounds, which is scaled from the bound.

Everything the title draws is scaled by the same factor, as its own
`cg_fovScale` does: a sight zooms in less at a wider view, and a scripted zoom
or split screen's narrower view keeps its proportion. The weapon in the
player's hands is drawn with the view's angle as well: at 120 it is smaller
and longer, and more of the arms shows. A wider view has more in it: the S.S.D.D. flight spends
14.9 ms a frame in the renderer at 90 where it spends 13.2 at 65.
