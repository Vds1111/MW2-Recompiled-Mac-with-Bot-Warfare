// XamInput* -- gamepad state. Backed by SDL3 when available; otherwise reports
// "no controller connected", which is a truthful answer the title handles.
#include <ppc_recomp_shared.h>
#include "kernel.h"
#ifdef __APPLE__
#include <TargetConditionals.h>
#endif
#include "../guest.h"
#include "../log.h"
#include "../env.h"
#include "../diagnostics.h"
#include "../console.h"
#include "../online/service.h"
#include "../player.h"
#include "../signin.h"
#include "../menu/menu.h"
#include "../stutters.h"
#include "../gpu/vulkan/renderer.h"
#include <atomic>

// Whether Bot Warfare's menu is open: its script says so (printconsole "BW_MENU:1" / "BW_MENU:0", read in
// runtime/bots/gsc.cpp), and the keyboard and mouse follow it below.
namespace bots { std::atomic<bool> g_menuOpen{false}; }

#ifdef MW2_USE_SDL
#include <SDL3/SDL.h>
#include <atomic>
#include <chrono>
#include <cmath>
#include <algorithm>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>
#endif

namespace
{
    // XINPUT_GAMEPAD, big-endian in guest memory.
    struct XInputGamepad
    {
        be16 buttons;
        uint8_t leftTrigger;
        uint8_t rightTrigger;
        be16 thumbLX, thumbLY, thumbRX, thumbRY;
    };
    struct XInputState
    {
        be32 packet;
        XInputGamepad gamepad;
    };
    struct XInputVibration { be16 left, right; };
    struct XInputCapabilities
    {
        uint8_t type, subType;
        be16 flags;
        XInputGamepad gamepad;
        XInputVibration vibration;
    };

#ifdef MW2_USE_SDL
    std::once_flag g_sdlOnce;
    // The title reads the pads on its main thread and sets the motors from
    // whichever thread runs its rumble; both open and close pads here.
    std::mutex g_padLock;
    SDL_Gamepad* g_pads[4] = {};

    void EnsureSdl()
    {
        std::call_once(g_sdlOnce, []{
            if (!SDL_InitSubSystem(SDL_INIT_GAMEPAD))
                LOGW("SDL gamepad init failed: %s", SDL_GetError());
        });
    }

    // What is plugged in, said whenever it changes: a controller the game does
    // not answer to is either not here at all, here as a joystick SDL has no
    // layout for, or one SDL was told to ignore.
    void SayDevices()
    {
        static std::string said = "?";
        int count = 0;
        SDL_JoystickID* ids = SDL_GetJoysticks(&count);
        std::string now;
        for (int i = 0; ids && i < count; i++)
        {
            const char* name = SDL_GetJoystickNameForID(ids[i]);
            char text[160];
            std::snprintf(text, sizeof text, "%s%s (%04X:%04X, %s)", i ? ", " : "", name ? name : "unnamed",
                          SDL_GetJoystickVendorForID(ids[i]), SDL_GetJoystickProductForID(ids[i]),
                          SDL_IsGamepad(ids[i]) ? "a gamepad" : "no gamepad layout known");
            now += text;
        }
        SDL_free(ids);
        if (now == said) return;
        said = now;
        if (now.empty()) LOGI("input: no controller is plugged in, as far as SDL sees");
        else LOGI("input: plugged in: %s", now.c_str());
        for (const char* hint : { SDL_HINT_GAMECONTROLLER_IGNORE_DEVICES, SDL_HINT_GAMECONTROLLER_IGNORE_DEVICES_EXCEPT })
            if (const char* value = SDL_GetHint(hint); value && *value)
                LOGI("input: SDL is told %s=%s", hint, value);
    }

    SDL_Gamepad* PadFor(uint32_t user)
    {
        if (user >= 4) return nullptr;
        EnsureSdl();
        std::lock_guard lock(g_padLock);
        if (g_pads[user] && !SDL_GamepadConnected(g_pads[user]))
        {
            SDL_CloseGamepad(g_pads[user]);
            g_pads[user] = nullptr;
        }
        // Looked for once a second, not on every poll: the title polls all
        // four users every frame, and each look allocates the device list.
        static std::chrono::steady_clock::time_point lastLook[4];
        const auto now = std::chrono::steady_clock::now();
        if (!g_pads[user] && now - lastLook[user] >= std::chrono::seconds(1))
        {
            lastLook[user] = now;
            if (user == 0) SayDevices();
            int count = 0;
            SDL_JoystickID* ids = SDL_GetGamepads(&count);
            if (ids)
            {
                if (int(user) < count) g_pads[user] = SDL_OpenGamepad(ids[user]);
                SDL_free(ids);
            }
            if (g_pads[user])
            {
                const char* name = SDL_GetGamepadName(g_pads[user]);
                LOGI("input: controller %u is %s", user, name ? name : "unnamed");
            }
        }
        return g_pads[user];
    }

    constexpr uint16_t BTN_DPAD_UP=0x0001, BTN_DPAD_DOWN=0x0002, BTN_DPAD_LEFT=0x0004,
        BTN_DPAD_RIGHT=0x0008, BTN_START=0x0010, BTN_BACK=0x0020, BTN_LTHUMB=0x0040,
        BTN_RTHUMB=0x0080, BTN_LB=0x0100, BTN_RB=0x0200, BTN_A=0x1000, BTN_B=0x2000,
        BTN_X=0x4000, BTN_Y=0x8000;

    struct Named { const char* name; uint16_t bit; };
    constexpr Named kButtons[] = {
        { "up", BTN_DPAD_UP }, { "down", BTN_DPAD_DOWN }, { "left", BTN_DPAD_LEFT },
        { "right", BTN_DPAD_RIGHT }, { "start", BTN_START }, { "back", BTN_BACK },
        { "lthumb", BTN_LTHUMB }, { "rthumb", BTN_RTHUMB }, { "lb", BTN_LB },
        { "rb", BTN_RB }, { "a", BTN_A }, { "b", BTN_B }, { "x", BTN_X }, { "y", BTN_Y },
        { "guide", signin::kGuide },
    };

    // The keyboard, for when there is no controller. Only useful with the window
    // open, since that is what gives SDL a focused surface to read keys from.
    struct Key { SDL_Scancode code; uint16_t bit; };
    constexpr Key kKeys[] = {
        { SDL_SCANCODE_RETURN, BTN_START },   { SDL_SCANCODE_ESCAPE, BTN_BACK },
        { SDL_SCANCODE_UP, BTN_DPAD_UP },     { SDL_SCANCODE_DOWN, BTN_DPAD_DOWN },
        { SDL_SCANCODE_LEFT, BTN_DPAD_LEFT }, { SDL_SCANCODE_RIGHT, BTN_DPAD_RIGHT },
        { SDL_SCANCODE_Z, BTN_A },            { SDL_SCANCODE_X, BTN_B },
        { SDL_SCANCODE_C, BTN_X },            { SDL_SCANCODE_V, BTN_Y },
        { SDL_SCANCODE_Q, BTN_LB },           { SDL_SCANCODE_E, BTN_RB },
    };

    uint16_t KeyboardButtons()
    {
        if (!SDL_WasInit(SDL_INIT_VIDEO)) return 0;
        const bool* keys = SDL_GetKeyboardState(nullptr);
        if (!keys) return 0;
        uint16_t buttons = 0;
        for (const Key& key : kKeys)
            if (keys[key.code]) buttons |= key.bit;
        return buttons;
    }

    // ---- PC BEGIN ----------------------------------------------------------------------------------------------
    // Keyboard and mouse, the way the PC plays: they stand in for controller 0 (alongside a real pad, if there is one).
    //
    //   WASD move (left stick)            mouse look (right stick)         left click fire (right trigger)
    //   right click aim down sights (left trigger), one click on and one off (MW2_ADS_HOLD=1: held instead)
    //   Space jump    C / Ctrl crouch (tap) or prone (hold)    Shift sprint    E / V melee    R / F reload and use
    //   G frag    Q flash    1 / 2 switch weapon    Tab scoreboard    Esc / Return start (pause)    Backspace back
    //   arrow keys: the d-pad.  Down arrow opens Bot Warfare's menu (d-pad down); while it is open W/A and S/D are
    //   its left/up and right/down (the triggers), Space selects. The menu tells this code when it
    //   opens and closes (printconsole "BW_MENU:1" / "BW_MENU:0" in its script), so any way out of it works.
    //   F7 says the menu is closed, if it ever gets out of step. F6 lets go of the mouse (and takes it again).
    //
    // MW2_PC_INPUT=0 turns it all off (the old arrow-key and Z/X/C/V keyboard comes back).
    // MW2_MOUSE_SENS=<n> scales mouse look (3 = default; the - and = keys turn it down and up as you play); MW2_MOUSE_DEADZONE=<n> is the stick value a first pixel of
    // movement is given, to get past the game's dead zone (default 9000, of 32767).
    bool PcEnabled()
    {
        static const bool on = []
        {
#if defined(__APPLE__) && TARGET_OS_IOS
            return false;
#else
            const char* text = env::Text("MW2_PC_INPUT");
            return !(text && text[0] == '0');
#endif
        }();
        return on;
    }

    float EnvNumber(const char* name, float fallback)
    {
        const char* text = env::Text(name);
        return text && *text ? float(std::atof(text)) : fallback;
    }

#if SDL_VERSION_ATLEAST(3, 2, 0)
    // The window's relative mouse mode has to be set on the main thread; the title polls from another one.
    SDL_Window* g_grabWindow = nullptr;
    void SDLCALL GrabOnMainThread(void* wanted)
    {
        if (wanted)
        {
            SDL_Window* window = SDL_GetKeyboardFocus();
            if (!window) return;
            if (g_grabWindow && g_grabWindow != window) SDL_SetWindowRelativeMouseMode(g_grabWindow, false);
            g_grabWindow = window;
            SDL_SetWindowRelativeMouseMode(window, true);
        }
        else if (g_grabWindow)
        {
            SDL_SetWindowRelativeMouseMode(g_grabWindow, false);
            g_grabWindow = nullptr;
        }
    }
#endif

    struct PcState
    {
        uint16_t buttons = 0;
        uint8_t triggers[2] = {};
        int16_t axes[4] = {};   // the guest's way up: Y points up
    };

    PcState PcPoll()
    {
        static PcState last;
        static std::chrono::steady_clock::time_point lastAt, lastGrabTry;
        static bool botMenu = false, adsOn = false, rmbWas = false, f6Was = false, f7Was = false;
        static bool grabWanted = true, grabbed = false, told = false;
        static float sens = EnvNumber("MW2_MOUSE_SENS", 3.0f);
        static bool minusWas = false, plusWas = false;

        // The title may poll more than once in a frame, and the mouse has only moved once.
        const auto now = std::chrono::steady_clock::now();
        if (now - lastAt < std::chrono::milliseconds(3)) return last;
        lastAt = now;
        if (!told)
        {
            told = true;
            LOGI("input: keyboard and mouse as on the PC (MW2_PC_INPUT=0 turns it off, F6 frees the mouse)");
        }

        PcState pc;
        if (!SDL_WasInit(SDL_INIT_VIDEO)) return last = pc;
        const bool* key = SDL_GetKeyboardState(nullptr);
        if (!key) return last = pc;
        SDL_Window* focus = SDL_GetKeyboardFocus();

        // The mouse is taken while the window has the keyboard; its movement since the last poll is the look.
        float mx = 0, my = 0;
        SDL_MouseButtonFlags mouse = SDL_GetRelativeMouseState(&mx, &my);
        if (!focus) { mx = my = 0; mouse = 0; }
        const bool f6 = key[SDL_SCANCODE_F6];
        if (f6 && !f6Was) grabWanted = !grabWanted;
        f6Was = f6;
        // F7: Bot Warfare's menu is closed after all (it can be left without the Down arrow), WASD is WASD again.
        const bool f7 = key[SDL_SCANCODE_F7];
        if (f7 && !f7Was) { bots::g_menuOpen = false; botMenu = false; adsOn = false; }
        f7Was = f7;
        // - and = turn the mouse sensitivity down and up; the log says the value, for MW2_MOUSE_SENS.
        const bool minus = key[SDL_SCANCODE_MINUS], plus = key[SDL_SCANCODE_EQUALS];
        if ((minus && !minusWas) || (plus && !plusWas))
        {
            sens = std::clamp(sens * (plus ? 1.25f : 0.8f), 0.2f, 20.0f);
            LOGI("input: mouse sensitivity %.2f (MW2_MOUSE_SENS=%.2f keeps it)", sens, sens);
        }
        minusWas = minus;
        plusWas = plus;
#if SDL_VERSION_ATLEAST(3, 2, 0)
        const bool wantGrab = grabWanted && focus;
        if (wantGrab)
        {
            if (!SDL_GetWindowRelativeMouseMode(focus) && now - lastGrabTry > std::chrono::milliseconds(500))
            {
                lastGrabTry = now;
                SDL_RunOnMainThread(GrabOnMainThread, reinterpret_cast<void*>(1), false);
            }
        }
        else if (grabbed || (!grabWanted && focus && SDL_GetWindowRelativeMouseMode(focus)))
        {
            SDL_RunOnMainThread(GrabOnMainThread, nullptr, false);
        }
        grabbed = wantGrab;
#else
        (void)lastGrabTry; (void)grabbed;
#endif
        if (!focus) { adsOn = false; rmbWas = false; return last = pc; }

        auto held = [&](SDL_Scancode a) { return key[a]; };
        const bool w = held(SDL_SCANCODE_W), a = held(SDL_SCANCODE_A), s = held(SDL_SCANCODE_S), d = held(SDL_SCANCODE_D);

        // Down arrow is d-pad down, which opens Bot Warfare's menu. The menu says itself when it is open: it can be
        // left from a submenu or with Exit as well as with the Down arrow.
        const bool down = held(SDL_SCANCODE_DOWN);
        const bool menuNow = bots::g_menuOpen.load();
        if (menuNow != botMenu) { botMenu = menuNow; adsOn = false; }

        uint16_t b = 0;
        auto set = [&](bool on, uint16_t bit) { if (on) b |= bit; };
        set(held(SDL_SCANCODE_SPACE), BTN_A);
        set(held(SDL_SCANCODE_C) || held(SDL_SCANCODE_LCTRL) || held(SDL_SCANCODE_RCTRL) ||
            held(SDL_SCANCODE_BACKSPACE), BTN_B);
        set(held(SDL_SCANCODE_R) || held(SDL_SCANCODE_F), BTN_X);
        set(held(SDL_SCANCODE_1) || held(SDL_SCANCODE_2), BTN_Y);
        set(held(SDL_SCANCODE_G), BTN_RB);
        set(held(SDL_SCANCODE_Q), BTN_LB);
        set(held(SDL_SCANCODE_LSHIFT) || held(SDL_SCANCODE_RSHIFT), BTN_LTHUMB);
        set(held(SDL_SCANCODE_E) || held(SDL_SCANCODE_V), BTN_RTHUMB);
        set(held(SDL_SCANCODE_TAB), BTN_BACK);
        set(held(SDL_SCANCODE_ESCAPE) || held(SDL_SCANCODE_RETURN), BTN_START);
        set(held(SDL_SCANCODE_UP), BTN_DPAD_UP);
        set(down, BTN_DPAD_DOWN);
        set(held(SDL_SCANCODE_LEFT), BTN_DPAD_LEFT);
        set(held(SDL_SCANCODE_RIGHT), BTN_DPAD_RIGHT);
        pc.buttons = b;

        const bool lmb = mouse & SDL_BUTTON_MASK(SDL_BUTTON_LEFT);
        const bool rmb = mouse & SDL_BUTTON_MASK(SDL_BUTTON_RIGHT);
        static const bool adsHold = env::Flag("MW2_ADS_HOLD");
        if (rmb && !rmbWas) adsOn = !adsOn;
        rmbWas = rmb;

        if (botMenu)
        {
            // The menu moves on the triggers (+speed_throw back, +attack forward); the player stays put.
            pc.triggers[0] = (w || a || rmb) ? 255 : 0;
            pc.triggers[1] = (s || d || lmb) ? 255 : 0;
        }
        else
        {
            pc.triggers[0] = (adsHold ? rmb : adsOn) ? 255 : 0;
            pc.triggers[1] = lmb ? 255 : 0;
            int x = (d ? 1 : 0) - (a ? 1 : 0), y = (w ? 1 : 0) - (s ? 1 : 0);
            const int mag = (x && y) ? 23170 : 32767;   // a diagonal is still one full stick
            pc.axes[0] = int16_t(x * mag);
            pc.axes[1] = int16_t(y * mag);
        }

        // The stick turns the view at a rate, the mouse moves it by a distance: a pixel of movement a frame is a
        // deflection, past the game's dead zone, and 20 or so a frame is full.
        static const float dead = EnvNumber("MW2_MOUSE_DEADZONE", 9000.0f);
        auto look = [&](float v) -> int16_t
        {
            if (v == 0) return 0;
            const float out = std::min(32767.0f, dead + std::fabs(v) * 1600.0f * sens);
            return int16_t(v < 0 ? -out : out);
        };
        pc.axes[2] = look(mx);
        pc.axes[3] = look(-my);
        return last = pc;
    }
    // ---- PC END ------------------------------------------------------------------------------------------------

    // MW2_INPUT_SCRIPT="2.5:start,6:a" presses buttons at fixed times, so a title
    // can be driven to a screen without a hand on the controller, and a bring-up
    // run reproduces the same path twice.
    //
    // An entry may name `lt` or `rt` for a trigger rather than a button, or a
    // stick direction -- `lx+ lx- ly+ ly- rx+ rx- ry+ ry-` -- and may carry a
    // third field giving how long to hold it: "40:lt:25" aims down the sights for
    // twenty-five seconds. Some of what the renderer does only happens while a
    // trigger is held -- MW2 turns its depth of field on when the player aims --
    // and some screens only respond to a stick: the first-boot brightness screen
    // will not accept anything until the slider has been moved, so a run that
    // only presses buttons sits on it forever. A name ending in `@2`, `@3` or
    // `@4` is that player's controller, which the script then stands in for:
    // "5:a@2" is the second player's A.
    // `bit` names a button; the trigger and stick pseudo-names set `trigger` or
    // `axis` instead, and `held` is how long the press lasts.
    struct Press
    {
        double at; uint16_t bit; int trigger = -1; double held = 0.2;
        int axis = -1; int16_t value = 0; uint32_t user = 0;
    };
    std::vector<Press> g_script;
    uint8_t g_scriptTriggers[4][2]{};
    int16_t g_scriptAxes[4][4]{};
    bool g_scriptAxisHeld[4][4]{};
    bool g_scripted[4]{};   // the script presses something on this controller

    // "lx+" is the left stick's X pushed fully one way, "ly-" the other.
    bool NamedAxis(const std::string& name, int& axis, int16_t& value)
    {
        if (name.size() != 3 || (name[2] != '+' && name[2] != '-')) return false;
        const int stick = name[0] == 'l' ? 0 : name[0] == 'r' ? 2 : -1;
        const int which = name[1] == 'x' ? 0 : name[1] == 'y' ? 1 : -1;
        if (stick < 0 || which < 0) return false;
        axis = stick + which;
        value = name[2] == '+' ? int16_t(32767) : int16_t(-32768);
        return true;
    }
    std::once_flag g_scriptOnce;
    std::chrono::steady_clock::time_point g_scriptStart;

    uint16_t ScriptedButtons(uint32_t user)
    {
        if constexpr (!diag::kOn) return 0;
        std::call_once(g_scriptOnce, [] {
            g_scriptStart = std::chrono::steady_clock::now();
            const char* text = diag::Text("MW2_INPUT_SCRIPT");
            if (!text) return;
            for (const char* at = text; *at; )
            {
                const char* comma = std::strchr(at, ',');
                std::string entry(at, comma ? comma - at : std::strlen(at));
                const size_t colon = entry.find(':');
                if (colon != std::string::npos)
                {
                    const double when = std::atof(entry.substr(0, colon).c_str());
                    std::string name = entry.substr(colon + 1);
                    double held = 0.2;
                    const size_t second = name.find(':');
                    if (second != std::string::npos)
                    {
                        held = std::atof(name.substr(second + 1).c_str());
                        if (held <= 0.0) held = 0.2;
                        name = name.substr(0, second);
                    }
                    uint32_t user = 0;
                    if (name.size() > 2 && name[name.size() - 2] == '@')
                    {
                        user = uint32_t(name.back() - '1') & 3;
                        name.resize(name.size() - 2);
                    }
                    const size_t before = g_script.size();
                    int axis = -1; int16_t value = 0;
                    if (name == "lt" || name == "rt")
                        g_script.push_back({ when, 0, name == "lt" ? 0 : 1, held });
                    else if (NamedAxis(name, axis, value))
                        g_script.push_back({ when, 0, -1, held, axis, value });
                    else
                        for (const Named& button : kButtons)
                            if (name == button.name)
                                g_script.push_back({ when, button.bit, -1, held });
                    for (size_t i = before; i < g_script.size(); i++) g_script[i].user = user;
                    if (g_script.size() > before) g_scripted[user] = true;
                }
                if (!comma) break;
                at = comma + 1;
            }
            static const char* kAxisNames[4] = { "left stick X", "left stick Y",
                                                 "right stick X", "right stick Y" };
            for (const Press& press : g_script)
                LOGI("input: controller %u, scripted %s at %.2f s for %.2f s (%04X)", press.user,
                     press.axis >= 0 ? kAxisNames[press.axis]
                                     : press.trigger < 0 ? "press"
                                     : press.trigger ? "right trigger" : "left trigger",
                     press.at, press.held, press.bit);
        });
        g_scriptTriggers[user][0] = g_scriptTriggers[user][1] = 0;
        for (int i = 0; i < 4; i++) { g_scriptAxes[user][i] = 0; g_scriptAxisHeld[user][i] = false; }
        if (!g_scripted[user]) return 0;

        // A press lasts long enough for a title polling at 60 Hz to see it and
        // short enough not to repeat, unless the entry asked to hold it.
        const double now = std::chrono::duration<double>(
            std::chrono::steady_clock::now() - g_scriptStart).count();
        uint16_t buttons = 0;
        for (const Press& press : g_script)
        {
            if (press.user != user || now < press.at || now >= press.at + press.held) continue;
            if (press.axis >= 0)
            {
                g_scriptAxes[user][press.axis] = press.value;
                g_scriptAxisHeld[user][press.axis] = true;
            }
            else if (press.trigger < 0) buttons |= press.bit;
            else                        g_scriptTriggers[user][press.trigger] = 255;
        }
        return buttons;
    }

    // A scripted stick entry moves nothing on its own, so a run with no pad
    // attached still has to take the path that applies it.
    bool ScriptedAxesHeld(uint32_t user)
    {
        for (bool held : g_scriptAxisHeld[user]) if (held) return true;
        return false;
    }

    // The packet number tells the title whether anything has changed since it
    // last looked. Incrementing it every poll says "changed" sixty times a second.
    struct Latch { uint32_t packet = 0; uint16_t buttons = 0; uint8_t triggers[2]{}; int16_t axes[4]{}; };
    Latch g_latch[4];
#endif
}

PPC_FUNC(__imp__XamInputGetState)
{
    // The title polls input once a frame from its main thread, which makes this
    // the cheapest place to hand the engine a scripted console command.
    online::Frame();
    console::Pump(ctx, base);

    uint32_t user  = ctx.r3.u32;
    uint32_t sAddr = ctx.r5.u32;
    auto* out = GuestPtr<XInputState>(sAddr);
    if (!out) { ctx.r3.u64 = X_ERROR_DEVICE_NOT_CONNECTED; return; }

#ifdef MW2_USE_SDL
    if (user >= 4) { *out = XInputState{}; ctx.r3.u64 = X_ERROR_DEVICE_NOT_CONNECTED; return; }
    SDL_Gamepad* pad = PadFor(user);
    // iPadOS turns a controller into keys for its own navigation -- the stick
    // into arrows, A into Return, B into Escape -- and SDL reports them as the
    // keyboard: the title saw every press twice, A as A and Start (the pause
    // menu), and a stick moving through a menu as the stick and the d-pad.
    // While a controller is there, its keys are not read.
#if defined(__APPLE__) && TARGET_OS_IOS
    const bool keyboard = user == 0 && !pad;
#else
    const bool keyboard = user == 0;
#endif
    const uint16_t elsewhere = uint16_t((keyboard && !PcEnabled() ? KeyboardButtons() : 0) | ScriptedButtons(user));
    if (pad || elsewhere || (user ? g_scripted[user] : ScriptedAxesHeld(0) || player::Wanted() || PcEnabled()))
    {

#ifndef __APPLE__
        // On Apple's systems the main thread's event pump keeps the pads'
        // state (gpu/vulkan/presenter.cpp, vk::RunMainThread).
        if (pad) SDL_UpdateGamepads();
#endif
        uint16_t b = elsewhere;
        auto down = [&](SDL_GamepadButton x){ return pad && SDL_GetGamepadButton(pad, x); };
        if (down(SDL_GAMEPAD_BUTTON_DPAD_UP))        b |= BTN_DPAD_UP;
        if (down(SDL_GAMEPAD_BUTTON_DPAD_DOWN))      b |= BTN_DPAD_DOWN;
        if (down(SDL_GAMEPAD_BUTTON_DPAD_LEFT))      b |= BTN_DPAD_LEFT;
        if (down(SDL_GAMEPAD_BUTTON_DPAD_RIGHT))     b |= BTN_DPAD_RIGHT;
        if (down(SDL_GAMEPAD_BUTTON_START))          b |= BTN_START;
        if (down(SDL_GAMEPAD_BUTTON_BACK))           b |= BTN_BACK;
        if (down(SDL_GAMEPAD_BUTTON_LEFT_STICK))     b |= BTN_LTHUMB;
        if (down(SDL_GAMEPAD_BUTTON_RIGHT_STICK))    b |= BTN_RTHUMB;
        if (down(SDL_GAMEPAD_BUTTON_LEFT_SHOULDER))  b |= BTN_LB;
        if (down(SDL_GAMEPAD_BUTTON_RIGHT_SHOULDER)) b |= BTN_RB;
        if (down(SDL_GAMEPAD_BUTTON_SOUTH))          b |= BTN_A;
        if (down(SDL_GAMEPAD_BUTTON_EAST))           b |= BTN_B;
        if (down(SDL_GAMEPAD_BUTTON_WEST))           b |= BTN_X;
        if (down(SDL_GAMEPAD_BUTTON_NORTH))          b |= BTN_Y;

        // A flash hunt (MW2_FLASH_HUNT, tools/flash_hunt.sh) takes the pad's Y
        // as its mark, because reaching for F7 mid-fight is not going to
        // happen. The title does not see it: Y switches weapon, and the
        // switch would change the very frames the mark keeps. A stutter hunt
        // (MW2_STUTTERS) marks a hitch with it the same way.
        static const bool hunting = diag::Flag("MW2_FLASH_HUNT") || stutters::On();
        if (hunting && user == 0 && pad)
        {
            static bool wasDown = false;
            const bool isDown = down(SDL_GAMEPAD_BUTTON_NORTH);
            if (isDown && !wasDown)
            {
                if (stutters::On()) stutters::Mark("pad Y");
                else vk::renderer::FlashSeen("pad Y");
            }
            wasDown = isDown;
            b &= uint16_t(~BTN_Y);
        }

        auto axis = [&](SDL_GamepadAxis a){ return pad ? SDL_GetGamepadAxis(pad, a) : int16_t(0); };
        uint8_t triggers[2] = {
            uint8_t(std::max<int>(axis(SDL_GAMEPAD_AXIS_LEFT_TRIGGER) >> 7,
                                  g_scriptTriggers[user][0])),
            uint8_t(std::max<int>(axis(SDL_GAMEPAD_AXIS_RIGHT_TRIGGER) >> 7,
                                  g_scriptTriggers[user][1])) };
        // The guest's Y axes point up; SDL's point down.
        int16_t axes[4] = { axis(SDL_GAMEPAD_AXIS_LEFTX),
                            int16_t(-1 - axis(SDL_GAMEPAD_AXIS_LEFTY)),
                            axis(SDL_GAMEPAD_AXIS_RIGHTX),
                            int16_t(-1 - axis(SDL_GAMEPAD_AXIS_RIGHTY)) };
        // Keyboard and mouse, on top of whatever the pad holds.
        if (user == 0 && PcEnabled())
        {
            const PcState pc = PcPoll();
            b |= pc.buttons;
            for (int i = 0; i < 2; i++) triggers[i] = uint8_t(std::max<int>(triggers[i], pc.triggers[i]));
            for (int i = 0; i < 4; i++)
                if (std::abs(int(pc.axes[i])) > std::abs(int(axes[i]))) axes[i] = pc.axes[i];
        }
        if (user == 0)
        {
            // What a person did, before the autopilot adds to it: a recorded
            // route keeps the presses (MW2_RECORD_PATH), and every shot is logged.
            player::SawPad(b, triggers[1]);
            player::Press press = player::Press::None;
            if (player::Steer(axes, press))
                switch (press)
                {
                case player::Press::A:    b |= BTN_A; break;
                case player::Press::Up:   b |= BTN_DPAD_UP; break;
                case player::Press::Left: b |= BTN_DPAD_LEFT; break;
                case player::Press::Fire: triggers[1] = 255; break;
                case player::Press::None: break;
                }
        }
        // A scripted stick entry overrides the pad and the autopilot while it is
        // held: a script that says where to look means it.
        for (int i = 0; i < 4; i++) if (g_scriptAxisHeld[user][i]) axes[i] = g_scriptAxes[user][i];

        // MW2_INPUT_LOG=1: every change of what the first pad holds, as SDL
        // names it and as the title is given it, with the time -- what a
        // button doing the wrong thing, or one press counting twice, needs.
        static const bool logInput = env::Flag("MW2_INPUT_LOG");
        if (logInput && user == 0 && pad)
        {
            static uint32_t lastRaw = 0;
            static uint16_t lastGiven = 0;
            uint32_t raw = 0;
            for (int i = 0; i < SDL_GAMEPAD_BUTTON_COUNT; i++)
                if (SDL_GetGamepadButton(pad, SDL_GamepadButton(i))) raw |= 1u << i;
            if (raw != lastRaw || b != lastGiven)
            {
                std::string names;
                for (int i = 0; i < SDL_GAMEPAD_BUTTON_COUNT; i++)
                    if (raw & (1u << i))
                    {
                        const char* name = SDL_GetGamepadStringForButton(SDL_GamepadButton(i));
                        names += std::string(names.empty() ? "" : "+") + (name ? name : "?");
                    }
                const double at = std::chrono::duration<double>(
                    std::chrono::steady_clock::now().time_since_epoch()).count();
                LOGI("input: %.3f pad %s -> title %04X", at, names.empty() ? "nothing" : names.c_str(), b);
                lastRaw = raw;
                lastGiven = b;
            }
        }

        // The settings menu takes the first controller while it is open, and
        // the chord that opens it (menu/menu.h).
        if (user == 0 && menu::Input(b, axes))
        {
            b = 0;
            triggers[0] = triggers[1] = 0;
            axes[0] = axes[1] = axes[2] = axes[3] = 0;
        }

        // The sign-in screen takes the controllers while it is open, the left
        // stick moving through it as the d-pad does.
        // The Guide button opens it, or Back and Start together where the
        // system keeps that button for itself.
        const uint16_t stick = axes[1] > 16000 ? BTN_DPAD_UP : axes[1] < -16000 ? BTN_DPAD_DOWN : uint16_t(0);
        const bool guide = down(SDL_GAMEPAD_BUTTON_GUIDE) || (b & (BTN_BACK | BTN_START)) == (BTN_BACK | BTN_START);
        const bool taken = signin::Input(user, uint16_t(b | stick | (guide ? signin::kGuide : 0)));
        b &= uint16_t(~signin::kGuide);
        if (taken)
        {
            b = 0;
            triggers[0] = triggers[1] = 0;
            axes[0] = axes[1] = axes[2] = axes[3] = 0;
        }

        Latch& latch = g_latch[user];
        const bool changed = latch.buttons != b ||
                             std::memcmp(latch.triggers, triggers, sizeof triggers) != 0 ||
                             std::memcmp(latch.axes, axes, sizeof axes) != 0;
        if (changed)
        {
            latch.packet++;
            latch.buttons = b;
            std::memcpy(latch.triggers, triggers, sizeof triggers);
            std::memcpy(latch.axes, axes, sizeof axes);
        }

        out->packet                = latch.packet;
        out->gamepad.buttons       = b;
        out->gamepad.leftTrigger   = triggers[0];
        out->gamepad.rightTrigger  = triggers[1];
        out->gamepad.thumbLX       = uint16_t(axes[0]);
        out->gamepad.thumbLY       = uint16_t(axes[1]);
        out->gamepad.thumbRX       = uint16_t(axes[2]);
        out->gamepad.thumbRY       = uint16_t(axes[3]);
        ctx.r3.u64 = X_ERROR_SUCCESS;
        return;
    }
#else
    (void)user;
#endif
    *out = XInputState{};
    ctx.r3.u64 = X_ERROR_DEVICE_NOT_CONNECTED;
}

PPC_FUNC(__imp__XamInputGetCapabilities)
{
    uint32_t user = ctx.r3.u32;
    auto* caps = GuestPtr<XInputCapabilities>(ctx.r5.u32);
    if (!caps) { ctx.r3.u64 = X_ERROR_DEVICE_NOT_CONNECTED; return; }
#ifdef MW2_USE_SDL
    if (PadFor(user) || (user < 4 && g_scripted[user]) || (user == 0 && (player::Wanted() || PcEnabled())))
    {
        // What a wired 360 pad reports: every control it has at full range,
        // and both motors.
        *caps = XInputCapabilities{};
        caps->type = 1;      // XINPUT_DEVTYPE_GAMEPAD
        caps->subType = 1;   // XINPUT_DEVSUBTYPE_GAMEPAD
        caps->gamepad.buttons = 0xF3FF;
        caps->gamepad.leftTrigger = caps->gamepad.rightTrigger = 0xFF;
        caps->gamepad.thumbLX = caps->gamepad.thumbLY = uint16_t(0xFFFF);
        caps->gamepad.thumbRX = caps->gamepad.thumbRY = uint16_t(0xFFFF);
        caps->vibration.left = caps->vibration.right = uint16_t(0xFFFF);
        ctx.r3.u64 = X_ERROR_SUCCESS;
        return;
    }
#else
    (void)user;
#endif
    *caps = XInputCapabilities{};
    ctx.r3.u64 = X_ERROR_DEVICE_NOT_CONNECTED;
}

// XamInputSetState(user, flags, vibration): the left motor is the heavy, low
// frequency one, as SDL's first argument is. A 360 motor keeps its speed until
// the next call, so the rumble is given SDL's longest duration rather than
// none: with none, SDL also stops resending it to pads that let a rumble lapse.
PPC_FUNC(__imp__XamInputSetState)
{
    const uint32_t user = ctx.r3.u32;
    if (user >= 4) { ctx.r3.u64 = X_ERROR_DEVICE_NOT_CONNECTED; return; }
    auto* v = GuestPtr<XInputVibration>(ctx.r5.u32);
    if (!v) { ctx.r3.u64 = X_ERROR_BAD_ARGUMENTS; return; }
#ifdef MW2_USE_SDL
    if (SDL_Gamepad* pad = PadFor(user))
    {
        std::lock_guard lock(g_padLock);
        if (g_pads[user] == pad)
        {
            const uint16_t left = v->left, right = v->right;
            const bool ok = SDL_RumbleGamepad(pad, left, right, 0xFFFF);
            // Said once per pad: the first rumble, or that the pad has none.
            static bool told[4];
            if ((left || right || !ok) && !told[user])
            {
                told[user] = true;
                if (ok) LOGI("input: controller %u rumbles (%04X, %04X)", user, left, right);
                else    LOGW("input: controller %u cannot rumble: %s", user, SDL_GetError());
            }
            ctx.r3.u64 = X_ERROR_SUCCESS;
            return;
        }
    }
#endif
    ctx.r3.u64 = X_ERROR_DEVICE_NOT_CONNECTED;
}
