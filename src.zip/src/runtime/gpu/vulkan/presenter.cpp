#include "presenter.h"
#include "../../platform.h"
#ifdef __APPLE__
#include <TargetConditionals.h>
#endif
#include "../../diagnostics.h"
#include "../../env.h"
#include "../../frame_rate.h"
#include "../../log.h"
#include "../../crash.h"
#include "../../console.h"
#include "../../stutters.h"
#include "../../signin.h"
#include "../../online/service.h"
#include "../../display_shape.h"

#if !defined(MW2_HAVE_VULKAN) || !defined(MW2_USE_SDL)
// Without a loader or a window system there is nothing to present to; the rest
// of the runtime carries on headless.
bool     vk::Start()           { return false; }
void     vk::StopPresenting()  {}
void     vk::Stop()            {}
void     vk::ShowImage(void*, uint32_t, uint32_t, uint64_t) {}
void     vk::WaitUntilTaken(uint64_t) {}
uint64_t vk::GuestBlankPeriod() { return 0; }
bool     vk::Running()         { return false; }
uint64_t vk::PresentedFrames() { return 0; }
#ifdef __APPLE__
#include <chrono>
#include <thread>
[[noreturn]] void vk::RunMainThread() { for (;;) std::this_thread::sleep_for(std::chrono::hours(1)); }
#endif
#else

#include <atomic>
#include <condition_variable>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <deque>
#include <mutex>
#include <shared_mutex>
#include <thread>
#include <chrono>
#include <algorithm>
#include <vector>

#include "capture.h"
#include "pipeline.h"
#include "renderer.h"
#include "menu_overlay.h"

#include <SDL3/SDL.h>
#include <SDL3/SDL_vulkan.h>
#include <vulkan/vulkan.h>
#include "util.h"

namespace
{
    constexpr uint32_t kWidth = 1280;
    constexpr uint32_t kHeight = 720;
    constexpr uint32_t kFramesInFlight = 2;

    struct Frame
    {
        VkCommandBuffer commands = VK_NULL_HANDLE;
        VkSemaphore acquired = VK_NULL_HANDLE;
        VkSemaphore rendered = VK_NULL_HANDLE;
        VkFence inFlight = VK_NULL_HANDLE;
    };

    struct Presenter
    {
        SDL_Window* window = nullptr;
        VkInstance instance = VK_NULL_HANDLE;
        VkSurfaceKHR surface = VK_NULL_HANDLE;
        VkPhysicalDevice physical = VK_NULL_HANDLE;
        VkDevice device = VK_NULL_HANDLE;
        uint32_t queueFamily = 0;
        VkQueue queue = VK_NULL_HANDLE;

        VkSwapchainKHR swapchain = VK_NULL_HANDLE;
        VkFormat swapchainFormat = VK_FORMAT_UNDEFINED;
        VkExtent2D extent{ kWidth, kHeight };
        std::vector<VkImage> images;
        // The window changed size, or the swapchain said it no longer fits:
        // remade before the next frame. A window of no size -- minimised -- has
        // nothing to remake it for, and frames are skipped until it has one.
        bool remakeSwapchain = false;
        bool fullscreen = false;
        uint64_t swapchainsMade = 0;

        VkCommandPool pool = VK_NULL_HANDLE;
        Frame frames[kFramesInFlight]{};
        uint32_t frameIndex = 0;

        // The sign-in screen (signin.h), laid over the frame while it is open:
        // its picture, the image it is copied to and the buffer it goes by.
        struct Overlay
        {
            signin::Image picture;
            VkImage image = VK_NULL_HANDLE;
            VkDeviceMemory imageMemory = VK_NULL_HANDLE;
            VkBuffer staging = VK_NULL_HANDLE;
            VkDeviceMemory stagingMemory = VK_NULL_HANDLE;
            void* mapped = nullptr;
            uint32_t width = 0, height = 0;
            uint64_t uploaded = 0;       // the picture's version the image holds
            bool everUploaded = false;
        } overlay;

        std::thread worker;
        std::atomic<bool> running{ false };
        std::atomic<bool> ready{ false };
        std::atomic<uint64_t> presented{ 0 };

        // The frames the renderer has finished and the window has not shown
        // yet, oldest first. Each is shown once, in order: the window used to
        // show whichever frame was newest when the title asked for a present,
        // and a frame finishing about then was shown twice or never.
        struct Queued
        {
            VkImage image = VK_NULL_HANDLE;
            uint32_t width = 0, height = 0;
            uint64_t serial = 0;
        };
        std::mutex lock;
        std::condition_variable wake, takenWake;
        std::deque<Queued> frameQueue;
        uint64_t taken = 0;                  // the last frame copied out or let go
        std::atomic<uint64_t> lastQueued{ 0 };

        // When each present reaches the screen (VK_KHR_present_wait), from a
        // thread of its own, which is what the guest's blank follows.
        bool presentWait = false;
        PFN_vkWaitForPresentKHR waitForPresent = nullptr;
        std::thread waiter;
        std::mutex waitLock;
        std::condition_variable waitWake;
        std::deque<uint64_t> waiting;        // present ids not yet seen on screen
        // Held shared while waiting on the swapchain, exclusive to replace it.
        std::shared_mutex swapchainLife;

        // The display's clock, as the presents reaching it measure it.
        double nominalNs = 0;                // from the display mode; 0 = not followed
        double periodNs = 0;
        int64_t lastShownNs = -1;
        uint64_t lastShownId = 0;
        bool exactRate = false;              // the display mode gave its rate exactly
        double buffered = 1.0;               // frames queued behind the one on screen
        uint64_t shownOnTime = 0, stretched = 0;
        uint64_t behindCount[4]{};           // 0, 1, 2, 3+ frames behind at each
        std::atomic<uint64_t> guestPeriodNs{ 0 };
        std::atomic<int64_t> guestPeriodAt{ 0 };
    };

    Presenter g;

    bool Check(VkResult r, const char* what)
    {
        if (r == VK_SUCCESS) return true;
        LOGW("vulkan: %s failed (%d)", what, int(r));
        return false;
    }

    // Under VK_INSTANCE_LAYERS=VK_LAYER_KHRONOS_validation, what the layer
    // reports goes into this log. Left to itself it prints to stdout, which
    // is block-buffered into a file and never flushed at this runtime's exit:
    // a run with a hundred errors read as a clean one.
    std::atomic<uint64_t> g_validationMessages{ 0 };
    VkDebugUtilsMessengerEXT g_messenger = VK_NULL_HANDLE;

    VKAPI_ATTR VkBool32 VKAPI_CALL Validation(VkDebugUtilsMessageSeverityFlagBitsEXT severity,
                                              VkDebugUtilsMessageTypeFlagsEXT,
                                              const VkDebugUtilsMessengerCallbackDataEXT* data,
                                              void*)
    {
        const uint64_t n = g_validationMessages.fetch_add(1, std::memory_order_relaxed);
        if (n < 500)
            LOGW("validation %s: %s",
                 severity >= VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT ? "error" : "warning",
                 data && data->pMessage ? data->pMessage : "?");
        return VK_FALSE;
    }

    bool Validating()
    {
        const char* layers = std::getenv("VK_INSTANCE_LAYERS");
        return layers && std::strstr(layers, "validation");
    }

    bool CreateInstance()
    {
        uint32_t extensionCount = 0;
        const char* const* sdlExtensions = SDL_Vulkan_GetInstanceExtensions(&extensionCount);
        if (!sdlExtensions) { LOGW("vulkan: SDL has no instance extensions (%s)", SDL_GetError()); return false; }
        // Only what the driver has. SDL on macOS asks for the portability
        // enumeration a Vulkan loader carries; MoltenVK linked in has no
        // loader in front of it, and an instance asked for it is refused.
        uint32_t offered = 0;
        vkEnumerateInstanceExtensionProperties(nullptr, &offered, nullptr);
        std::vector<VkExtensionProperties> available(offered);
        vkEnumerateInstanceExtensionProperties(nullptr, &offered, available.data());
        auto has = [&](const char* name) {
            return std::any_of(available.begin(), available.end(),
                               [&](const VkExtensionProperties& e) { return std::strcmp(e.extensionName, name) == 0; });
        };
        std::vector<const char*> extensions;
        for (uint32_t i = 0; i < extensionCount; i++)
        {
            if (has(sdlExtensions[i])) extensions.push_back(sdlExtensions[i]);
            else LOGI("vulkan: instance extension %s is not offered here; going without", sdlExtensions[i]);
        }
        const bool portability = has("VK_KHR_portability_enumeration");

        VkApplicationInfo app{ VK_STRUCTURE_TYPE_APPLICATION_INFO };
        app.pApplicationName = "mw2recomp";
        app.apiVersion = VK_API_VERSION_1_2;

        VkDebugUtilsMessengerCreateInfoEXT messenger{
            VK_STRUCTURE_TYPE_DEBUG_UTILS_MESSENGER_CREATE_INFO_EXT };
        messenger.messageSeverity = VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT |
                                    VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT;
        messenger.messageType = VK_DEBUG_UTILS_MESSAGE_TYPE_GENERAL_BIT_EXT |
                                VK_DEBUG_UTILS_MESSAGE_TYPE_VALIDATION_BIT_EXT;
        messenger.pfnUserCallback = Validation;
        const bool validating = Validating();
        if (validating) extensions.push_back(VK_EXT_DEBUG_UTILS_EXTENSION_NAME);

        VkInstanceCreateInfo info{ VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO };
        info.pNext = validating ? &messenger : nullptr;   // instance creation's own messages
        // Through a loader, MoltenVK's device is listed only when asked for.
        if (portability) info.flags |= 0x00000001;   // VK_INSTANCE_CREATE_ENUMERATE_PORTABILITY_BIT_KHR
        info.pApplicationInfo = &app;
        info.enabledExtensionCount = uint32_t(extensions.size());
        info.ppEnabledExtensionNames = extensions.data();
        if (!Check(vkCreateInstance(&info, nullptr, &g.instance), "vkCreateInstance")) return false;
        if (validating)
        {
            auto create = reinterpret_cast<PFN_vkCreateDebugUtilsMessengerEXT>(
                vkGetInstanceProcAddr(g.instance, "vkCreateDebugUtilsMessengerEXT"));
            if (!create || create(g.instance, &messenger, nullptr, &g_messenger) != VK_SUCCESS)
                LOGW("vulkan: validation asked for, but its messages cannot be caught");
            else
                LOGI("vulkan: validation messages go to this log");
        }
        return true;
    }

    bool PickDevice()
    {
        uint32_t count = 0;
        vkEnumeratePhysicalDevices(g.instance, &count, nullptr);
        if (!count) { LOGW("vulkan: no physical devices"); return false; }
        std::vector<VkPhysicalDevice> devices(count);
        vkEnumeratePhysicalDevices(g.instance, &count, devices.data());

        // Prefer a discrete device, but take whatever can present.
        VkPhysicalDevice fallback = VK_NULL_HANDLE;
        uint32_t fallbackFamily = 0;
        for (VkPhysicalDevice candidate : devices)
        {
            uint32_t families = 0;
            vkGetPhysicalDeviceQueueFamilyProperties(candidate, &families, nullptr);
            std::vector<VkQueueFamilyProperties> properties(families);
            vkGetPhysicalDeviceQueueFamilyProperties(candidate, &families, properties.data());

            for (uint32_t i = 0; i < families; i++)
            {
                if (!(properties[i].queueFlags & VK_QUEUE_GRAPHICS_BIT)) continue;
                VkBool32 canPresent = VK_FALSE;
                vkGetPhysicalDeviceSurfaceSupportKHR(candidate, i, g.surface, &canPresent);
                if (!canPresent) continue;

                VkPhysicalDeviceProperties info{};
                vkGetPhysicalDeviceProperties(candidate, &info);
                if (info.deviceType == VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU)
                {
                    g.physical = candidate; g.queueFamily = i;
                    LOGI("vulkan: %s", info.deviceName);
                    return true;
                }
                if (!fallback) { fallback = candidate; fallbackFamily = i; }
                break;
            }
        }
        if (!fallback) { LOGW("vulkan: no device can present to the window"); return false; }
        g.physical = fallback; g.queueFamily = fallbackFamily;
        VkPhysicalDeviceProperties info{};
        vkGetPhysicalDeviceProperties(g.physical, &info);
        LOGI("vulkan: %s", info.deviceName);
        return true;
    }

    // The renderer draws on this device when there is a window, so it is made
    // the way pipeline.cpp makes its own, with the swapchain beside.
    bool CreateDevice()
    {
        std::vector<const char*> extensions{ VK_KHR_SWAPCHAIN_EXTENSION_NAME };
        // Present ids and waiting on them say when a frame reached the
        // screen, which is the display's clock.
        VkPhysicalDevicePresentIdFeaturesKHR presentId{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PRESENT_ID_FEATURES_KHR };
        VkPhysicalDevicePresentWaitFeaturesKHR presentWait{
            VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PRESENT_WAIT_FEATURES_KHR };
        void* features = nullptr;
        if (vk::pipeline::DeviceHasExtension(g.physical, VK_KHR_PRESENT_ID_EXTENSION_NAME) &&
            vk::pipeline::DeviceHasExtension(g.physical, VK_KHR_PRESENT_WAIT_EXTENSION_NAME))
        {
            presentId.pNext = &presentWait;
            VkPhysicalDeviceFeatures2 query{ VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2 };
            query.pNext = &presentId;
            vkGetPhysicalDeviceFeatures2(g.physical, &query);
            if (presentId.presentId && presentWait.presentWait)
            {
                extensions.push_back(VK_KHR_PRESENT_ID_EXTENSION_NAME);
                extensions.push_back(VK_KHR_PRESENT_WAIT_EXTENSION_NAME);
                presentWait.pNext = nullptr;
                features = &presentId;
                g.presentWait = true;
            }
        }
        void* device = nullptr;
        void* queue = nullptr;
        if (!vk::pipeline::CreateDevice(g.physical, g.queueFamily, extensions.data(),
                                        uint32_t(extensions.size()), &device, &queue, features))
            return false;
        g.device = static_cast<VkDevice>(device);
        g.queue = static_cast<VkQueue>(queue);
        if (g.presentWait)
        {
            g.waitForPresent = reinterpret_cast<PFN_vkWaitForPresentKHR>(
                vkGetDeviceProcAddr(g.device, "vkWaitForPresentKHR"));
            g.presentWait = g.waitForPresent != nullptr;
        }
        if (!g.presentWait)
            LOGW("vulkan: the device cannot say when a present reaches the screen"
                 " (VK_KHR_present_wait); the guest's blank keeps its own 60 Hz clock");
        return true;
    }

    bool CreateSwapchain()
    {
        VkSurfaceCapabilitiesKHR caps{};
        vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g.physical, g.surface, &caps);
        // The surface says what size it is, except where the window system
        // leaves it to the application (both dimensions at the maximum), and
        // then the window's own size in pixels is the answer, held within
        // what the surface allows.
        if (caps.currentExtent.width != UINT32_MAX) g.extent = caps.currentExtent;
        else
        {
            int width = 0, height = 0;
            SDL_GetWindowSizeInPixels(g.window, &width, &height);
            g.extent.width = std::clamp(uint32_t(std::max(width, 0)),
                                        caps.minImageExtent.width, caps.maxImageExtent.width);
            g.extent.height = std::clamp(uint32_t(std::max(height, 0)),
                                         caps.minImageExtent.height, caps.maxImageExtent.height);
        }
        if (!g.extent.width || !g.extent.height) return false;   // minimised: nothing to make

        uint32_t formatCount = 0;
        vkGetPhysicalDeviceSurfaceFormatsKHR(g.physical, g.surface, &formatCount, nullptr);
        if (!formatCount) return false;
        std::vector<VkSurfaceFormatKHR> formats(formatCount);
        vkGetPhysicalDeviceSurfaceFormatsKHR(g.physical, g.surface, &formatCount, formats.data());
        VkSurfaceFormatKHR chosen = formats[0];
        for (const auto& f : formats)
            if (f.format == VK_FORMAT_B8G8R8A8_UNORM) { chosen = f; break; }
        g.swapchainFormat = chosen.format;

        VkSwapchainCreateInfoKHR info{ VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR };
        info.surface = g.surface;
        info.minImageCount = std::max(caps.minImageCount, 2u);
        info.imageFormat = chosen.format;
        info.imageColorSpace = chosen.colorSpace;
        info.imageExtent = g.extent;
        info.imageArrayLayers = 1;
        // The renderer's frame is blitted in, so a transfer destination.
        // Transfer source too, for the screenshots (MW2_SCREENSHOT_AT).
        info.imageUsage = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT |
                          VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
        info.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
        info.preTransform = caps.currentTransform;
        info.compositeAlpha = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR;
        info.presentMode = VK_PRESENT_MODE_FIFO_KHR;      // always supported
        info.clipped = VK_TRUE;
        // The one being replaced, if any, so the driver can carry over what it
        // can; it is destroyed once the new one exists.
        VkSwapchainKHR old = g.swapchain;
        info.oldSwapchain = old;

        VkSwapchainKHR made = VK_NULL_HANDLE;
        const bool ok = Check(vkCreateSwapchainKHR(g.device, &info, nullptr, &made),
                              "vkCreateSwapchainKHR");
        {
            // Nothing waits on a present of the old one once it is gone.
            std::unique_lock life(g.swapchainLife);
            if (old) vkDestroySwapchainKHR(g.device, old, nullptr);
            g.swapchain = ok ? made : VK_NULL_HANDLE;
            std::lock_guard waiting(g.waitLock);
            g.waiting.clear();
            g.lastShownNs = -1;
        }
        if (!ok) return false;
        g.swapchainsMade++;

        uint32_t imageCount = 0;
        vkGetSwapchainImagesKHR(g.device, g.swapchain, &imageCount, nullptr);
        g.images.resize(imageCount);
        vkGetSwapchainImagesKHR(g.device, g.swapchain, &imageCount, g.images.data());
        LOGI("vulkan: swapchain %ux%u, %u images", g.extent.width, g.extent.height, imageCount);
        return true;
    }

    bool CreateFrames()
    {
        VkCommandPoolCreateInfo poolInfo{ VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO };
        poolInfo.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
        poolInfo.queueFamilyIndex = g.queueFamily;
        if (!Check(vkCreateCommandPool(g.device, &poolInfo, nullptr, &g.pool), "vkCreateCommandPool"))
            return false;

        for (auto& frame : g.frames)
        {
            VkCommandBufferAllocateInfo allocate{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
            allocate.commandPool = g.pool;
            allocate.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
            allocate.commandBufferCount = 1;
            if (!Check(vkAllocateCommandBuffers(g.device, &allocate, &frame.commands), "vkAllocateCommandBuffers"))
                return false;

            VkSemaphoreCreateInfo semaphore{ VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO };
            VkFenceCreateInfo fence{ VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
            fence.flags = VK_FENCE_CREATE_SIGNALED_BIT;
            if (!Check(vkCreateSemaphore(g.device, &semaphore, nullptr, &frame.acquired), "vkCreateSemaphore") ||
                !Check(vkCreateSemaphore(g.device, &semaphore, nullptr, &frame.rendered), "vkCreateSemaphore") ||
                !Check(vkCreateFence(g.device, &fence, nullptr, &frame.inFlight), "vkCreateFence"))
                return false;
        }
        return true;
    }

    // Only the presenter's own command buffers touch the swapchain images, so
    // waiting for its two fences is enough to replace it; the renderer's queue
    // work carries on. A window without a size keeps the old swapchain, which
    // stays unusable, and every frame until it has one is skipped.
    void RemakeSwapchain()
    {
        VkFence fences[kFramesInFlight];
        for (uint32_t i = 0; i < kFramesInFlight; i++) fences[i] = g.frames[i].inFlight;
        vk::pipeline::Failed(vkWaitForFences(g.device, kFramesInFlight, fences, VK_TRUE, UINT64_MAX),
                             "the presenter's fences before a resize");
        // The overlay's views of the old images are done with, as they are.
        vk::overlay::ForgetSwapchain(g.device);
        if (CreateSwapchain()) g.remakeSwapchain = false;
    }

    // Where the frame lands in a window of another shape: as large as fits
    // at the frame's own proportions, centred, the rest black. Nothing is
    // squashed, and the window can be any shape at all.
    //
    // MW2_FILL fills a screen of another shape instead (a MacBook's is 16:10
    // and taller): "zoom" shows the middle of the frame at the screen's
    // proportions, trimming its edges, and "stretch" stretches all of it.
    // Read at every frame, so the settings menu changes it at once.
    void Letterbox(uint32_t frameWidth, uint32_t frameHeight, VkOffset3D& from, VkOffset3D& to,
                   VkOffset3D& sourceFrom, VkOffset3D& sourceTo)
    {
        sourceFrom = { 0, 0, 0 };
        sourceTo = { int32_t(frameWidth), int32_t(frameHeight), 1 };
        const char* fill = env::Text("MW2_FILL");
        const bool zoom = fill && std::strcmp(fill, "zoom") == 0;
        // A title told its display is 4:3 drew for one into its 16:9 buffer,
        // which the console's scaler stretched to the set: so does this.
        if (display::FourByThree() || zoom || (fill && std::strcmp(fill, "stretch") == 0))
        {
            from = { 0, 0, 0 };
            to = { int32_t(g.extent.width), int32_t(g.extent.height), 1 };
            if (!zoom || display::FourByThree()) return;
            const uint64_t byWidth = uint64_t(g.extent.width) * frameHeight;
            const uint64_t byHeight = uint64_t(g.extent.height) * frameWidth;
            uint32_t width = frameWidth, height = frameHeight;
            if (byWidth > byHeight) height = uint32_t(uint64_t(frameWidth) * g.extent.height / g.extent.width);
            else width = uint32_t(uint64_t(frameHeight) * g.extent.width / g.extent.height);
            width = std::clamp(width, 1u, frameWidth);
            height = std::clamp(height, 1u, frameHeight);
            sourceFrom = { int32_t((frameWidth - width) / 2), int32_t((frameHeight - height) / 2), 0 };
            sourceTo = { sourceFrom.x + int32_t(width), sourceFrom.y + int32_t(height), 1 };
            return;
        }
        const uint64_t byWidth = uint64_t(g.extent.width) * frameHeight;
        const uint64_t byHeight = uint64_t(g.extent.height) * frameWidth;
        uint32_t width = g.extent.width, height = g.extent.height;
        if (byWidth > byHeight) width = uint32_t(byHeight / frameHeight);   // wider than the frame
        else height = uint32_t(byWidth / frameWidth);                       // taller than the frame
        width = std::max(width, 1u);
        height = std::max(height, 1u);
        from = { int32_t((g.extent.width - width) / 2), int32_t((g.extent.height - height) / 2), 0 };
        to = { from.x + int32_t(width), from.y + int32_t(height), 1 };
    }

    void Waiter();

    // MW2_SCREENSHOT_AT=<seconds>[,<seconds>...]: the window's picture as it
    // goes to the screen -- the frame with the sign-in screen, the settings
    // menu and the frame counter over it -- written as PPM into
    // MW2_SCREENSHOTS (the current folder without it) at those times after
    // the window opens. What a frame dump (MW2_DUMP_FRAMES) cannot show, since
    // the renderer's frames have nothing of this runtime's own drawn on them.
    struct Shot
    {
        VkBuffer buffer = VK_NULL_HANDLE;
        VkDeviceMemory memory = VK_NULL_HANDLE;
        void* mapped = nullptr;
        VkDeviceSize size = 0;
        std::vector<double> at;
        std::chrono::steady_clock::time_point since;
        bool started = false;
        uint32_t taken = 0;
    } g_shot;

    bool ShotDue()
    {
        if (!g_shot.started)
        {
            g_shot.started = true;
            g_shot.since = std::chrono::steady_clock::now();
            if (const char* list = env::Text("MW2_SCREENSHOT_AT"))
                for (const char* at = list; *at;)
                {
                    char* end = nullptr;
                    const double seconds = std::strtod(at, &end);
                    if (end == at) break;
                    g_shot.at.push_back(seconds);
                    at = *end == ',' ? end + 1 : end;
                }
            std::sort(g_shot.at.begin(), g_shot.at.end(), std::greater<double>());
        }
        if (g_shot.at.empty()) return false;
        const double elapsed = std::chrono::duration<double>(std::chrono::steady_clock::now() - g_shot.since).count();
        if (elapsed < g_shot.at.back()) return false;
        g_shot.at.pop_back();
        return true;
    }

    bool ShotBuffer(VkDeviceSize size)
    {
        if (g_shot.size >= size) return true;
        if (g_shot.buffer) { vkDestroyBuffer(g.device, g_shot.buffer, nullptr); vkFreeMemory(g.device, g_shot.memory, nullptr); }
        g_shot = Shot{ VK_NULL_HANDLE, VK_NULL_HANDLE, nullptr, 0, g_shot.at, g_shot.since, true, g_shot.taken };
        VkBufferCreateInfo info{ VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO };
        info.size = size;
        info.usage = VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        if (vkCreateBuffer(g.device, &info, nullptr, &g_shot.buffer) != VK_SUCCESS) return false;
        VkMemoryRequirements needs{};
        vkGetBufferMemoryRequirements(g.device, g_shot.buffer, &needs);
        VkPhysicalDeviceMemoryProperties memory{};
        vkGetPhysicalDeviceMemoryProperties(g.physical, &memory);
        VkMemoryAllocateInfo allocate{ VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO };
        allocate.allocationSize = needs.size;
        allocate.memoryTypeIndex = vk::util::FindMemory(memory, needs.memoryTypeBits,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        if (allocate.memoryTypeIndex == UINT32_MAX ||
            vkAllocateMemory(g.device, &allocate, nullptr, &g_shot.memory) != VK_SUCCESS ||
            vkBindBufferMemory(g.device, g_shot.buffer, g_shot.memory, 0) != VK_SUCCESS ||
            vkMapMemory(g.device, g_shot.memory, 0, VK_WHOLE_SIZE, 0, &g_shot.mapped) != VK_SUCCESS)
            return false;
        g_shot.size = size;
        return true;
    }

    void WriteShot(uint32_t width, uint32_t height)
    {
        const char* folder = env::Text("MW2_SCREENSHOTS");
        char path[1024];
        std::snprintf(path, sizeof path, "%s%sscreenshot_%03u.ppm", folder ? folder : "", folder ? "/" : "",
                      ++g_shot.taken);
        std::FILE* file = std::fopen(path, "wb");
        if (!file) { LOGW("vulkan: could not write %s", path); return; }
        std::fprintf(file, "P6\n%u %u\n255\n", width, height);
        const bool bgra = g.swapchainFormat == VK_FORMAT_B8G8R8A8_UNORM || g.swapchainFormat == VK_FORMAT_B8G8R8A8_SRGB;
        std::vector<uint8_t> line(size_t(width) * 3);
        const auto* pixels = static_cast<const uint8_t*>(g_shot.mapped);
        for (uint32_t y = 0; y < height; y++)
        {
            for (uint32_t x = 0; x < width; x++)
            {
                const uint8_t* p = pixels + (size_t(y) * width + x) * 4;
                line[x * 3 + 0] = bgra ? p[2] : p[0];
                line[x * 3 + 1] = p[1];
                line[x * 3 + 2] = bgra ? p[0] : p[2];
            }
            std::fwrite(line.data(), 1, line.size(), file);
        }
        std::fclose(file);
        LOGI("vulkan: wrote the window's picture to %s", path);
    }

    // The guest's blank follows the display when the display runs at the
    // console's 60 Hz and the device can say when a present reaches it. A
    // display at another rate cannot show 60 frames a second evenly anyway,
    // and the title keeps its own 60.
    void FollowTheDisplay()
    {
        double hz = 0;
        if (const SDL_DisplayMode* mode = SDL_GetCurrentDisplayMode(SDL_GetDisplayForWindow(g.window)))
        {
            // The mode's exact rate, from its pixel clock and totals, when
            // the window system gives it; otherwise measured (SawDisplayed).
            g.exactRate = mode->refresh_rate_denominator != 0;
            hz = g.exactRate ? double(mode->refresh_rate_numerator) / mode->refresh_rate_denominator
                             : double(mode->refresh_rate);
        }
        g.periodNs = 1e9 / (hz > 0 ? hz : 60.0);
        if (!g.presentWait) return;
        if (hz >= 59.0 && hz <= 61.0)
        {
            g.nominalNs = g.periodNs;
            LOGI("vulkan: the display runs at %.4f Hz; the guest's blank follows it", hz);
        }
        // A ProMotion panel (the iPad's) at 120 Hz, or any whole multiple of
        // 60: the guest's blank follows every second (third...) of its blanks,
        // where on its own clock it drifted against them and a frame was now
        // and then held a blank longer or let go a blank early.
        else if (const double ratio = std::round(hz / 60.0);
                 ratio >= 2 && std::fabs(hz - 60.0 * ratio) <= ratio)
        {
            g.periodNs *= ratio;
            g.nominalNs = g.periodNs;
            LOGI("vulkan: the display runs at %.3f Hz; the guest's blank follows every %.0f of its blanks",
                 hz, ratio);
        }
        else
            LOGI("vulkan: the display runs at %.3f Hz, not 60; the guest's blank keeps its own"
                 " clock", hz);
        g.waiter = std::thread(Waiter);
    }

    // How much longer the guest's blank may be than the display's while
    // latency drains: 0.5%, a frame in about three seconds, and nobody sees it.
    constexpr double kNudge = 0.005;

    int64_t Nanoseconds()
    {
        return std::chrono::duration_cast<std::chrono::nanoseconds>(
                   std::chrono::steady_clock::now().time_since_epoch()).count();
    }

    // Frame `id` reached the screen at `at` (under waitLock). A frame held on
    // screen longer than a blank is a stutter; the guest's blank is set to the
    // display's, a touch longer while more than one frame waits behind the
    // one on screen, so latency a stall built up drains away unseen. It is
    // never set shorter: a frame late once leaves one frame in hand from then
    // on, which is double buffering, and when the renderer cannot keep up,
    // hurrying the title only gives it more to fall behind on.
    //
    // The display's period comes from its mode where the mode says it
    // exactly. Measured from these completions it read 17.1 ms against the
    // panel's 16.67 in a run where frames were often late -- late completions
    // pull an average up -- and the guest's blank followed it down to 58.5 Hz.
    // On the console the blank the title counts is the display's own; a
    // timer of ours beside it drifts, and every so often a frame is shown
    // twice or waits a frame longer.
    void SawDisplayed(uint64_t id, int64_t at)
    {
        const uint64_t queued = g.lastQueued.load(std::memory_order_relaxed);
        // Off the blank nothing waits its turn behind the frame on screen:
        // the frames after it are let go for the newest (DrawOneFrame).
        const double behind = frame_rate::Console() && queued > id ? double(queued - id) : 0.0;
        if (g.lastShownNs >= 0 && id > g.lastShownId)
        {
            const double gap = double(at - g.lastShownNs);
            const uint64_t frames = id - g.lastShownId;
            const long blanks = std::lround(gap / g.periodNs);
            // Only a gap no longer than the period can be trusted to measure it.
            if (!g.exactRate && frames == 1 && gap <= g.periodNs * 1.02 && gap > g.periodNs * 0.9)
                g.periodNs += (gap - g.periodNs) / 256.0;
            if (blanks > long(frames))
                stutters::Displayed(id, uint32_t(blanks - long(frames)), gap / 1e6);
        }
        g.lastShownNs = at;
        g.lastShownId = id;
        g.buffered += (behind - g.buffered) / 16.0;
        g.behindCount[std::min<uint64_t>(uint64_t(behind), 3)]++;
        if (!g.nominalNs) return;
        const double stretch = g.buffered > 1.5 ? kNudge : 0.0;
        (stretch > 0 ? g.stretched : g.shownOnTime)++;
        g.guestPeriodNs.store(uint64_t(g.periodNs * (1.0 + stretch)), std::memory_order_relaxed);
        g.guestPeriodAt.store(at, std::memory_order_relaxed);
    }

    // Waits on each present in turn until it is on the screen. Its own thread,
    // as DXVK does it: the window thread cannot wait on the display without
    // falling behind the frames it has to show.
    void Waiter()
    {
        crash::RegisterThread("vulkan present wait");
        platform::InteractiveThreadPriority();
        while (g.running.load(std::memory_order_relaxed))
        {
            uint64_t id = 0;
            {
                std::unique_lock lock(g.waitLock);
                g.waitWake.wait_for(lock, std::chrono::milliseconds(50),
                                    [] { return !g.waiting.empty() || !g.running; });
                if (g.waiting.empty()) continue;
                id = g.waiting.front();
            }
            VkResult r = VK_ERROR_OUT_OF_DATE_KHR;
            {
                std::shared_lock life(g.swapchainLife);
                if (g.swapchain)
                    r = g.waitForPresent(g.device, g.swapchain, id, 20'000'000);   // 20 ms
            }
            if (r == VK_TIMEOUT) continue;   // still waiting; lets a resize in
            const int64_t at = Nanoseconds();
            std::lock_guard lock(g.waitLock);
            // A resize cleared the list, and this id went with the old swapchain.
            if (g.waiting.empty() || g.waiting.front() != id) continue;
            g.waiting.pop_front();
            if (r == VK_SUCCESS) SawDisplayed(id, at);
            else g.lastShownNs = -1;
        }
    }

    // The frames queued up to now are let go without being shown: there is
    // no swapchain to show them in (a minimised window), and the renderer must
    // not wait on a window that cannot take them.
    void LetGo()
    {
        std::lock_guard lock(g.lock);
        if (g.frameQueue.empty()) return;
        g.taken = std::max(g.taken, g.frameQueue.back().serial);
        g.frameQueue.clear();
        g.takenWake.notify_all();
    }

    // Shows the oldest queued frame, or with `idle` the window's own colour
    // before the renderer has finished any.
    void DestroyOverlay()
    {
        auto& o = g.overlay;
        if (o.image) vkDestroyImage(g.device, o.image, nullptr);
        if (o.imageMemory) vkFreeMemory(g.device, o.imageMemory, nullptr);
        if (o.staging) vkDestroyBuffer(g.device, o.staging, nullptr);
        if (o.stagingMemory) vkFreeMemory(g.device, o.stagingMemory, nullptr);
        o.image = VK_NULL_HANDLE; o.imageMemory = VK_NULL_HANDLE;
        o.staging = VK_NULL_HANDLE; o.stagingMemory = VK_NULL_HANDLE;
        o.mapped = nullptr; o.width = o.height = 0; o.everUploaded = false;
    }

    bool CreateOverlay(uint32_t width, uint32_t height)
    {
        auto& o = g.overlay;
        VkPhysicalDeviceMemoryProperties memory{};
        vkGetPhysicalDeviceMemoryProperties(g.physical, &memory);

        VkImageCreateInfo image{ VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO };
        image.imageType = VK_IMAGE_TYPE_2D;
        image.format = VK_FORMAT_B8G8R8A8_UNORM;
        image.extent = { width, height, 1 };
        image.mipLevels = 1;
        image.arrayLayers = 1;
        image.samples = VK_SAMPLE_COUNT_1_BIT;
        image.tiling = VK_IMAGE_TILING_OPTIMAL;
        image.usage = VK_IMAGE_USAGE_TRANSFER_SRC_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT;
        image.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
        if (!Check(vkCreateImage(g.device, &image, nullptr, &o.image), "the sign-in screen's image")) return false;
        VkMemoryRequirements needs{};
        vkGetImageMemoryRequirements(g.device, o.image, &needs);
        VkMemoryAllocateInfo allocate{ VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO };
        allocate.allocationSize = needs.size;
        allocate.memoryTypeIndex = vk::util::FindMemory(memory, needs.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
        if (allocate.memoryTypeIndex == UINT32_MAX ||
            !Check(vkAllocateMemory(g.device, &allocate, nullptr, &o.imageMemory), "the sign-in screen's memory") ||
            !Check(vkBindImageMemory(g.device, o.image, o.imageMemory, 0), "the sign-in screen's memory"))
            return false;

        VkBufferCreateInfo buffer{ VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO };
        buffer.size = VkDeviceSize(width) * height * 4;
        buffer.usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT;
        if (!Check(vkCreateBuffer(g.device, &buffer, nullptr, &o.staging), "the sign-in screen's buffer")) return false;
        vkGetBufferMemoryRequirements(g.device, o.staging, &needs);
        allocate.allocationSize = needs.size;
        allocate.memoryTypeIndex = vk::util::FindMemory(memory, needs.memoryTypeBits,
            VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
        if (allocate.memoryTypeIndex == UINT32_MAX ||
            !Check(vkAllocateMemory(g.device, &allocate, nullptr, &o.stagingMemory), "the sign-in screen's buffer") ||
            !Check(vkBindBufferMemory(g.device, o.staging, o.stagingMemory, 0), "the sign-in screen's buffer") ||
            !Check(vkMapMemory(g.device, o.stagingMemory, 0, VK_WHOLE_SIZE, 0, &o.mapped), "the sign-in screen's buffer"))
            return false;
        o.width = width;
        o.height = height;
        return true;
    }

    // The sign-in screen over the middle of the swapchain image, which is in
    // TRANSFER_DST layout. It is opaque, so a copy does it.
    void DrawOverlay(const Frame& frame, VkImage target)
    {
        auto& o = g.overlay;
        if (!signin::Picture(g.extent.height, o.picture)) return;
        const uint32_t width = o.picture.width, height = o.picture.height;
        if (width > g.extent.width || height > g.extent.height) return;

        const bool resized = width != o.width || height != o.height;
        if (resized || o.uploaded != o.picture.version || !o.everUploaded)
        {
            // The other frames' commands may still be reading the image and
            // the buffer; this happens at a press of a button, not per frame.
            for (const Frame& other : g.frames)
                if (&other != &frame) vkWaitForFences(g.device, 1, &other.inFlight, VK_TRUE, UINT64_MAX);
            if (resized)
            {
                DestroyOverlay();
                if (!CreateOverlay(width, height)) { DestroyOverlay(); return; }
            }
            std::memcpy(o.mapped, o.picture.pixels.data(), o.picture.pixels.size());
            vk::util::Barrier(frame.commands, o.image, VK_IMAGE_ASPECT_COLOR_BIT,
                              VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                              0, VK_ACCESS_TRANSFER_WRITE_BIT,
                              VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
            VkBufferImageCopy copy{};
            copy.imageSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 };
            copy.imageExtent = { width, height, 1 };
            vkCmdCopyBufferToImage(frame.commands, o.staging, o.image,
                                   VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &copy);
            vk::util::Barrier(frame.commands, o.image, VK_IMAGE_ASPECT_COLOR_BIT,
                              VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                              VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_READ_BIT,
                              VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
            o.uploaded = o.picture.version;
            o.everUploaded = true;
        }

        // The frame's blit wrote where this one writes.
        vk::util::Barrier(frame.commands, target, VK_IMAGE_ASPECT_COLOR_BIT,
                          VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                          VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_WRITE_BIT,
                          VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
        VkImageBlit blit{};
        blit.srcSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 };
        blit.srcOffsets[1] = { int32_t(width), int32_t(height), 1 };
        blit.dstSubresource = blit.srcSubresource;
        const int32_t left = int32_t(g.extent.width - width) / 2, top = int32_t(g.extent.height - height) / 2;
        blit.dstOffsets[0] = { left, top, 0 };
        blit.dstOffsets[1] = { left + int32_t(width), top + int32_t(height), 1 };
        vkCmdBlitImage(frame.commands, o.image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                       target, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &blit, VK_FILTER_NEAREST);
    }

    void DrawOneFrame(bool idle)
    {
        if (g.remakeSwapchain) RemakeSwapchain();
        if (g.remakeSwapchain || !g.swapchain) { LetGo(); return; }

        Frame& frame = g.frames[g.frameIndex];
        if (vk::pipeline::Failed(vkWaitForFences(g.device, 1, &frame.inFlight, VK_TRUE, UINT64_MAX),
                                 "the presenter's fence"))
            return;

        // FIFO: this is where the window waits for the display, with the
        // frame it will show still in the queue, so the queue's length is
        // how far the renderer is ahead of the screen.
        uint32_t imageIndex = 0;
        VkResult acquired = vkAcquireNextImageKHR(g.device, g.swapchain, UINT64_MAX,
                                                  frame.acquired, VK_NULL_HANDLE, &imageIndex);
        // Out of date: nothing was acquired, and the semaphore is untouched;
        // remade next frame. Suboptimal: an image was acquired and is shown,
        // since the semaphore it signals has to be waited on, and then remade.
        if (acquired == VK_ERROR_OUT_OF_DATE_KHR) { g.remakeSwapchain = true; return; }
        if (acquired == VK_SUBOPTIMAL_KHR) g.remakeSwapchain = true;
        else if (acquired != VK_SUCCESS) return;

        Presenter::Queued shown;
        if (!idle)
        {
            std::lock_guard lock(g.lock);
            // Off the blank (MW2_FPS_LIMIT) the title finishes frames whenever
            // it likes, and the display still takes one a blank: the newest is
            // shown and the ones before it are let go.
            while (!frame_rate::Console() && g.frameQueue.size() > 1)
            {
                g.taken = std::max(g.taken, g.frameQueue.front().serial);
                g.frameQueue.pop_front();
                g.takenWake.notify_all();
            }
            if (!g.frameQueue.empty())
            {
                shown = g.frameQueue.front();
                g.frameQueue.pop_front();
            }
        }

        vkResetFences(g.device, 1, &frame.inFlight);
        vkResetCommandBuffer(frame.commands, 0);

        VkCommandBufferBeginInfo begin{ VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
        begin.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
        vkBeginCommandBuffer(frame.commands, &begin);

        VkImage image = g.images[imageIndex];
        // At the transfer stage, which the acquire's semaphore holds back, so the
        // transition does not run before the image is ours.
        vk::util::Barrier(frame.commands, image, VK_IMAGE_ASPECT_COLOR_BIT,
                          VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                          0, VK_ACCESS_TRANSFER_WRITE_BIT,
                          VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);

        if (shown.image && shown.width && shown.height)
        {
            // The renderer's frame, scaled to the window at its own proportions.
            // It is in TRANSFER_SRC layout, and its owner does not draw into it
            // again until this copy is submitted (WaitUntilTaken). The bars are
            // cleared first; the clear covers the whole image and the blit
            // paints over the middle, which is cheaper than working out the bars.
            VkImageBlit blit{};
            blit.srcSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 };
            blit.dstSubresource = blit.srcSubresource;
            Letterbox(shown.width, shown.height, blit.dstOffsets[0], blit.dstOffsets[1],
                      blit.srcOffsets[0], blit.srcOffsets[1]);
            const bool bars = blit.dstOffsets[0].x || blit.dstOffsets[0].y;
            if (bars)
            {
                VkClearColorValue black{};
                VkImageSubresourceRange range{ VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 };
                vkCmdClearColorImage(frame.commands, image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                     &black, 1, &range);
                vk::util::Barrier(frame.commands, image, VK_IMAGE_ASPECT_COLOR_BIT,
                                  VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                  VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL,
                                  VK_ACCESS_TRANSFER_WRITE_BIT, VK_ACCESS_TRANSFER_WRITE_BIT,
                                  VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
            }
            vkCmdBlitImage(frame.commands, shown.image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL,
                           image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &blit, VK_FILTER_LINEAR);
        }
        else
        {
            // A recognisably "nothing rendered yet" colour rather than black, so
            // a blank window is distinguishable from a dead one.
            VkClearColorValue colour{};
            colour.float32[0] = 0.06f; colour.float32[1] = 0.07f; colour.float32[2] = 0.10f; colour.float32[3] = 1.0f;
            VkImageSubresourceRange range{ VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 };
            vkCmdClearColorImage(frame.commands, image, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, &colour, 1, &range);
        }
        DrawOverlay(frame, image);
        // The settings menu and the frame counter, drawn over all of it.
        const bool menuDrawn = vk::overlay::Draw(
            { g.instance, g.physical, g.device, g.queue, g.queueFamily, g.swapchainFormat,
              uint32_t(g.images.size()) },
            frame.commands, image, g.extent);

        VkImageLayout layout = menuDrawn ? VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
                                         : VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL;
        VkAccessFlags access = menuDrawn ? VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT : VK_ACCESS_TRANSFER_WRITE_BIT;
        VkPipelineStageFlags stage = menuDrawn ? VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT
                                               : VK_PIPELINE_STAGE_TRANSFER_BIT;
        const VkDeviceSize shotBytes = VkDeviceSize(g.extent.width) * g.extent.height * 4;
        const bool shooting = ShotDue() && ShotBuffer(shotBytes);
        if (shooting)
        {
            vk::util::Barrier(frame.commands, image, VK_IMAGE_ASPECT_COLOR_BIT, layout,
                              VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, access, VK_ACCESS_TRANSFER_READ_BIT,
                              stage, VK_PIPELINE_STAGE_TRANSFER_BIT);
            VkBufferImageCopy copy{};
            copy.imageSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 };
            copy.imageExtent = { g.extent.width, g.extent.height, 1 };
            vkCmdCopyImageToBuffer(frame.commands, image, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, g_shot.buffer, 1, &copy);
            layout = VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL;
            access = VK_ACCESS_TRANSFER_READ_BIT;
            stage = VK_PIPELINE_STAGE_TRANSFER_BIT;
        }
        vk::util::Barrier(frame.commands, image, VK_IMAGE_ASPECT_COLOR_BIT, layout, VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
                          access, 0, stage, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
        vkEndCommandBuffer(frame.commands);

        VkPipelineStageFlags wait = VK_PIPELINE_STAGE_TRANSFER_BIT | VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT;
        VkSubmitInfo submit{ VK_STRUCTURE_TYPE_SUBMIT_INFO };
        submit.waitSemaphoreCount = 1;
        submit.pWaitSemaphores = &frame.acquired;
        submit.pWaitDstStageMask = &wait;
        submit.commandBufferCount = 1;
        submit.pCommandBuffers = &frame.commands;
        submit.signalSemaphoreCount = 1;
        submit.pSignalSemaphores = &frame.rendered;
        // The GPU thread submits to this queue too, and Vulkan requires a queue
        // to be externally synchronised for a present as for a submission. Two
        // holds rather than one, so a submission of the renderer's can go
        // between them.
        {
            std::lock_guard queueLock(vk::pipeline::QueueMutex());
            vk::pipeline::Failed(vkQueueSubmit(g.queue, 1, &submit, frame.inFlight),
                                 "the presenter's submission");
        }
        if (shooting &&
            vkWaitForFences(g.device, 1, &frame.inFlight, VK_TRUE, UINT64_MAX) == VK_SUCCESS)
            WriteShot(g.extent.width, g.extent.height);
        // The copy is in the queue ahead of anything the renderer submits from
        // now on, so the renderer may draw over the image.
        if (shown.serial)
        {
            std::lock_guard lock(g.lock);
            g.taken = std::max(g.taken, shown.serial);
            g.takenWake.notify_all();
        }
        if (shown.serial) stutters::Shown(shown.serial);

        VkPresentInfoKHR present{ VK_STRUCTURE_TYPE_PRESENT_INFO_KHR };
        present.waitSemaphoreCount = 1;
        present.pWaitSemaphores = &frame.rendered;
        present.swapchainCount = 1;
        present.pSwapchains = &g.swapchain;
        present.pImageIndices = &imageIndex;
        // The frame's serial is its present id: they only ever go up.
        VkPresentIdKHR id{ VK_STRUCTURE_TYPE_PRESENT_ID_KHR };
        id.swapchainCount = 1;
        id.pPresentIds = &shown.serial;
        if (g.presentWait && shown.serial) present.pNext = &id;
        // Out of date and suboptimal here mean the window changed under the
        // present: the swapchain is remade before the next frame. Only a lost
        // device is a failure.
        const VkResult presented = [&] {
            std::lock_guard queueLock(vk::pipeline::QueueMutex());
            return vkQueuePresentKHR(g.queue, &present);
        }();
        if (presented == VK_ERROR_OUT_OF_DATE_KHR || presented == VK_SUBOPTIMAL_KHR)
            g.remakeSwapchain = true;
        else
            vk::pipeline::Failed(presented, "present");
        if (g.presentWait && shown.serial &&
            (presented == VK_SUCCESS || presented == VK_SUBOPTIMAL_KHR))
        {
            std::lock_guard waiting(g.waitLock);
            g.waiting.push_back(shown.serial);
            g.waitWake.notify_one();
        }

        g.frameIndex = (g.frameIndex + 1) % kFramesInFlight;
        g.presented.fetch_add(1, std::memory_order_relaxed);
    }

    void Teardown()
    {
        if (g.device)
        {
            vkDeviceWaitIdle(g.device);
            vk::overlay::Shutdown(g.device);
            if (g_shot.buffer) vkDestroyBuffer(g.device, g_shot.buffer, nullptr);
            if (g_shot.memory) vkFreeMemory(g.device, g_shot.memory, nullptr);
            g_shot.buffer = VK_NULL_HANDLE;
            g_shot.memory = VK_NULL_HANDLE;
            DestroyOverlay();
            for (auto& frame : g.frames)
            {
                if (frame.acquired) vkDestroySemaphore(g.device, frame.acquired, nullptr);
                if (frame.rendered) vkDestroySemaphore(g.device, frame.rendered, nullptr);
                if (frame.inFlight) vkDestroyFence(g.device, frame.inFlight, nullptr);
            }
            if (g.pool) vkDestroyCommandPool(g.device, g.pool, nullptr);
            if (g.swapchain) vkDestroySwapchainKHR(g.device, g.swapchain, nullptr);
            vkDestroyDevice(g.device, nullptr);
            g.pool = VK_NULL_HANDLE;
            g.swapchain = VK_NULL_HANDLE;
            g.device = VK_NULL_HANDLE;
            for (auto& frame : g.frames) frame = Frame{};
        }
        if (g.surface) vkDestroySurfaceKHR(g.instance, g.surface, nullptr);
        if (g_messenger)
        {
            LOGI("vulkan: %llu validation messages", (unsigned long long)g_validationMessages.load());
            if (auto destroy = reinterpret_cast<PFN_vkDestroyDebugUtilsMessengerEXT>(
                    vkGetInstanceProcAddr(g.instance, "vkDestroyDebugUtilsMessengerEXT")))
                destroy(g.instance, g_messenger, nullptr);
            g_messenger = VK_NULL_HANDLE;
        }
        if (g.instance) vkDestroyInstance(g.instance, nullptr);
#ifdef __APPLE__
        // Off the main thread a window is not ours to touch; the process is
        // ending, and the system takes it down with it.
        if (g.window && SDL_IsMainThread()) SDL_DestroyWindow(g.window);
#else
        if (g.window) SDL_DestroyWindow(g.window);
#endif
        g.surface = VK_NULL_HANDLE;
        g.instance = VK_NULL_HANDLE;
        g.window = nullptr;
    }

    bool Bring()
    {
        if (!SDL_InitSubSystem(SDL_INIT_VIDEO))
        {
            LOGW("vulkan: SDL video would not start (%s)", SDL_GetError());
            return false;
        }
        // Resizable, and fullscreen from the start under MW2_FULLSCREEN=1 --
        // borderless at the desktop's resolution, which SDL gives a window
        // asked for fullscreen without a mode of its own. F8 toggles it.
        g.fullscreen = env::Flag("MW2_FULLSCREEN");
        // Apple's screens count windows in points, two or three pixels each:
        // without high density the swapchain is the points' size, and an
        // iPad's 2752x2064 panel was given a 1600x1200 picture to stretch.
        SDL_WindowFlags density = 0;
#ifdef __APPLE__
        density = SDL_WINDOW_HIGH_PIXEL_DENSITY;
#endif
        g.window = SDL_CreateWindow("Modern Warfare 2", kWidth, kHeight,
                                    SDL_WINDOW_VULKAN | SDL_WINDOW_RESIZABLE | density |
                                    (g.fullscreen ? SDL_WINDOW_FULLSCREEN : 0));
        if (!g.window) { LOGW("vulkan: no window (%s)", SDL_GetError()); return false; }
        if (!CreateInstance()) return false;
        if (!SDL_Vulkan_CreateSurface(g.window, g.instance, nullptr, &g.surface))
        {
            LOGW("vulkan: no surface (%s)", SDL_GetError());
            return false;
        }
        if (!PickDevice() || !CreateDevice() || !CreateSwapchain() || !CreateFrames())
            return false;
        // Everything else that touches the GPU -- the texture cache, the
        // renderer -- allocates against this device rather than one of its own,
        // because an image cannot be shared between two.
        vk::pipeline::Initialise(g.device, g.physical, g.queue, g.queueFamily, g.instance);
        return true;
    }

    void Worker()
    {
        crash::RegisterThread("vulkan presenter");
        if (!Bring())
        {
            LOGW("vulkan: presenting disabled, continuing headless");
            g.running = false;
            g.ready = true;
            return;
        }
        FollowTheDisplay();
        g.ready = true;
        LOGI("vulkan: presenter running");

        while (g.running.load(std::memory_order_relaxed))
        {
            SDL_Event event;
            while (SDL_PollEvent(&event))
                // Not `g.running = false`: that stops the pump, and with nothing
                // pumping, the window stops repainting and SDL stops seeing the
                // keyboard and the pad, which looks like a freeze while the guest
                // runs on headless forever. Ending the process is what closing the
                // window means. The shutdown joins this thread, so it runs on one
                // of its own and this loop keeps the window alive until it lands.
                if (event.type == SDL_EVENT_QUIT ||
                    event.type == SDL_EVENT_WINDOW_CLOSE_REQUESTED)
                    crash::RequestExit("the window was closed");
                // F10, F11, F9, F7 and F5 are diagnostics.
                // F10 captures the next frames that draw the world. A defect
                // that only appears in motion has to be caught by somebody
                // watching for it; no time chosen in advance will do.
                else if (diag::kOn && event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat &&
                         event.key.scancode == SDL_SCANCODE_F10)
                    vk::capture::RequestNow(4);
                // F11 captures every world frame until pressed again, for
                // flicker: which frame goes wrong is not known in advance.
                // Not F12, which is RenderDoc's own key.
                else if (diag::kOn && event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat &&
                         event.key.scancode == SDL_SCANCODE_F11)
                    vk::capture::ToggleStream();
                // F9 asks the title where the player stands, so a spot seen in
                // play can be given back to setviewpos. The answer is printed
                // under MW2_ENGINE_LOG=1.
                else if (diag::kOn && event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat &&
                         event.key.scancode == SDL_SCANCODE_F9)
                {
                    console::RunNow("viewpos");
                    LOGI("console: F9 -- viewpos asked for");
                }
                // F5 runs the console command MW2_F5 names: `noclip`, say, once
                // a level's opening is behind.
                else if (diag::kOn && event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat &&
                         event.key.scancode == SDL_SCANCODE_F5 && diag::Text("MW2_F5"))
                {
                    console::RunNow(diag::Text("MW2_F5"));
                    LOGI("console: F5 -- %s", diag::Text("MW2_F5"));
                }
                // F7: "I saw a flash just now" -- a mark in the log, and the
                // frames before it written out when MW2_FLASH_FRAMES keeps them.
                // Under MW2_STUTTERS it marks a hitch instead.
                else if (diag::kOn && event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat &&
                         event.key.scancode == SDL_SCANCODE_F7)
                {
                    if (stutters::On()) stutters::Mark("F7");
                    else vk::renderer::FlashSeen("F7");
                }
                // F6 opens the online service's invitation, when it has one:
                // Steam's overlay, with a friend list to pick from.
                else if (event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat &&
                         event.key.scancode == SDL_SCANCODE_F6)
                {
                    if (auto* service = online::Get()) service->InviteFriends();
                }
                // F8 toggles fullscreen. The size change that follows arrives as
                // an event like any other resize.
                else if (event.type == SDL_EVENT_KEY_DOWN && !event.key.repeat &&
                         event.key.scancode == SDL_SCANCODE_F8)
                {
                    g.fullscreen = !g.fullscreen;
                    if (!SDL_SetWindowFullscreen(g.window, g.fullscreen))
                    {
                        LOGW("vulkan: fullscreen would not toggle (%s)", SDL_GetError());
                        g.fullscreen = !g.fullscreen;
                    }
                }
                // The window's size in pixels changed -- dragged, maximised,
                // fullscreen -- and the swapchain has to be its size.
                else if (event.type == SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED ||
                         event.type == SDL_EVENT_WINDOW_RESIZED)
                    g.remakeSwapchain = true;

            // A frame to show, or 16 ms to go round the events again. Until the
            // renderer has finished one, the window shows its own colour.
            bool queued = false;
            {
                std::unique_lock lock(g.lock);
                g.wake.wait_for(lock, std::chrono::milliseconds(16),
                                [] { return !g.frameQueue.empty() || !g.running; });
                queued = !g.frameQueue.empty();
            }
            if (!g.running) break;
            // In the background nothing may reach the GPU; the frames waiting
            // are let go, as for a hidden window (WaitUntilTaken).
            if (vk::pipeline::SubmissionSuspended()) continue;
            if (queued) DrawOneFrame(false);
            else if (!g.presented.load(std::memory_order_relaxed)) DrawOneFrame(true);
        }
        LOGI("vulkan: presenter stopped after %llu frames, %llu swapchains",
             (unsigned long long)g.presented.load(), (unsigned long long)g.swapchainsMade);
    }
}

#ifdef __APPLE__
namespace
{
    // Start's request for the main thread, and the main thread's word that
    // the presenter it ran has stopped: there is no worker to join.
    std::atomic<bool> g_mainAsked{ false };
    std::atomic<bool> g_presenterStarted{ false };
    std::mutex g_presenterDoneLock;
    std::condition_variable g_presenterDoneWake;
    bool g_presenterDone = false;
}

#if TARGET_OS_IOS
namespace
{
    // Called from UIKit's own notifications, before they return: a queued
    // event would arrive after the app had gone, its GPU work refused.
    bool SDLCALL WatchTheApp(void*, SDL_Event* event)
    {
        switch (event->type)
        {
        case SDL_EVENT_WILL_ENTER_BACKGROUND:
            vk::renderer::SaveCachesSoon();
            vk::pipeline::SuspendSubmission();
            break;
        case SDL_EVENT_DID_ENTER_FOREGROUND:
            vk::pipeline::ResumeSubmission();
            break;
        default:
            break;
        }
        return true;
    }
}
#endif

[[noreturn]] void vk::RunMainThread()
{
    crash::RegisterThread("main thread (window)");
    // Video and the pads up front, on this thread, where Cocoa and UIKit want
    // them; the pads' state then arrives through this thread's event pump
    // (kernel/input.cpp leaves SDL_UpdateGamepads to it).
    if (!SDL_InitSubSystem(SDL_INIT_VIDEO | SDL_INIT_GAMEPAD))
        LOGW("vulkan: SDL would not start on the main thread (%s)", SDL_GetError());
#if TARGET_OS_IOS
    SDL_AddEventWatch(WatchTheApp, nullptr);
#endif
    for (;;)
    {
        if (g_mainAsked.exchange(false, std::memory_order_acq_rel))
        {
            Worker();
            std::lock_guard held(g_presenterDoneLock);
            g_presenterDone = true;
            g_presenterDoneWake.notify_all();
        }
        // Until the window is asked for, and once it has gone: the system's
        // events, so the app answers it, and quitting still quits.
        SDL_Event event;
        while (SDL_PollEvent(&event))
            if (event.type == SDL_EVENT_QUIT) crash::RequestExit("the app was quit");
        SDL_Delay(5);
    }
}
#endif

bool vk::Start()
{
    // Every build opens it; MW2_WINDOW=0 keeps it shut, for a headless
    // measurement run.
    const bool window = !env::Text("MW2_WINDOW") || env::Flag("MW2_WINDOW");
    if (!window) return false;

    g.running = true;
#ifdef __APPLE__
    g_presenterStarted = true;
    g_mainAsked.store(true, std::memory_order_release);
#else
    g.worker = std::thread(Worker);
#endif
    while (!g.ready.load(std::memory_order_acquire)) std::this_thread::yield();
    return g.running.load();
}

void vk::ShowImage(void* image, uint32_t width, uint32_t height, uint64_t serial)
{
    if (!g.running.load(std::memory_order_relaxed)) return;
    std::lock_guard lock(g.lock);
    g.frameQueue.push_back({ static_cast<VkImage>(image), width, height, serial });
    g.lastQueued.store(serial, std::memory_order_relaxed);
    g.wake.notify_one();
}

void vk::WaitUntilTaken(uint64_t serial)
{
    if (!serial || !g.running.load(std::memory_order_relaxed)) return;
    std::unique_lock lock(g.lock);
    if (g.takenWake.wait_for(lock, std::chrono::milliseconds(250),
                             [&] { return g.taken >= serial || !g.running; }))
        return;
    // A quarter of a second without the window taking a frame: it is hidden
    // or its display has stopped. The game does not wait on a window.
    while (!g.frameQueue.empty() && g.frameQueue.front().serial <= serial) g.frameQueue.pop_front();
    g.taken = std::max(g.taken, serial);
    static std::atomic<uint32_t> told{ 0 };
    if (told.fetch_add(1) < 4)
        LOGW("vulkan: the window took no frame in 250 ms; frames up to %llu let go unshown",
             (unsigned long long)serial);
}

uint64_t vk::GuestBlankPeriod()
{
    const uint64_t period = g.guestPeriodNs.load(std::memory_order_relaxed);
    // Nothing reached the screen for half a second (minimised, or no window
    // yet): there is no display clock to follow.
    if (!period || Nanoseconds() - g.guestPeriodAt.load(std::memory_order_relaxed) > 500'000'000)
        return 0;
    return period;
}

// The window thread has to stop before anything that owns an image it might be
// showing is torn down, but the device has to outlive that teardown -- so
// stopping and destroying are two steps rather than one.
void vk::StopPresenting()
{
#ifdef __APPLE__
    if (!g_presenterStarted.exchange(false)) return;
#else
    if (!g.worker.joinable()) return;
#endif
    g.running = false;
    { std::lock_guard lock(g.lock); g.wake.notify_all(); g.takenWake.notify_all(); }
    { std::lock_guard lock(g.waitLock); g.waitWake.notify_all(); }
#ifdef __APPLE__
    {
        std::unique_lock held(g_presenterDoneLock);
        g_presenterDoneWake.wait(held, [] { return g_presenterDone; });
    }
#else
    g.worker.join();
#endif
    if (g.waiter.joinable())
    {
        g.waiter.join();
        LOGI("vulkan: the display's blank measured %.1f us; frames behind the one on screen"
             " when it was shown: 0 x%llu, 1 x%llu, 2 x%llu, 3+ x%llu; the guest's blank ran"
             " at the display's for %llu, longer for %llu",
             g.periodNs / 1000.0, (unsigned long long)g.behindCount[0],
             (unsigned long long)g.behindCount[1], (unsigned long long)g.behindCount[2],
             (unsigned long long)g.behindCount[3], (unsigned long long)g.shownOnTime,
             (unsigned long long)g.stretched);
    }
}

void vk::Stop()
{
    StopPresenting();
    Teardown();
}

bool vk::Running() { return g.running.load(); }
uint64_t vk::PresentedFrames() { return g.presented.load(); }

#endif  // MW2_HAVE_VULKAN && MW2_USE_SDL
