#include <atomic>
#include "bots.h"
namespace bots { void SetCount(uint32_t) {} void SetSkill(Skill) {} void SetTeams(Teams) {} uint32_t Count() { return 0; } }

namespace { std::atomic<bool> g_bwMenuOpen{false}; }
bool bots::MenuOpen() { return g_bwMenuOpen.load(std::memory_order_relaxed); }
void bots::SetMenuOpen(bool open) { g_bwMenuOpen.store(open, std::memory_order_relaxed); }
