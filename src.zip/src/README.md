# Modern Warfare 2, recompiled

Call of Duty: Modern Warfare 2 (2009) for the Xbox 360, running natively on PC.
Not an emulator: the game's executables are recompiled ahead of time. No game
files are included; you need your own disc.

> **iPad, iPadOS and macOS port (this fork)** by [CNX (@vrcnx)](https://github.com/vrcnx),
> built with [Claude Code](https://claude.com/claude-code). Call of Duty: Modern
> Warfare 2 multiplayer running natively on Apple Silicon: M-series iPads (iPad
> Pro, iPad Air) and Macs, at 60 fps with an Xbox or PlayStation controller.
> No emulator and no streaming. Upstream project:
> [PaulCombal/mw2-recompiled](https://github.com/PaulCombal/mw2-recompiled).
>
> - **iPadOS / iOS app** — Vulkan through MoltenVK on Metal, the panel's full
>   resolution, a 4:3 picture that fills the iPad's screen, ProMotion 120 Hz
>   pacing, pause and resume when the app is put away.
> - **macOS (Apple Silicon)** — the same runtime as a native arm64 build.
> - **Offline bots** — up to 17 bots in System Link and Private Match, played
>   by a brain of this port's own: field of view and line of sight, reaction
>   time, human-speed aim, strafing, hunting, four skill levels, and routes
>   learned from where players walk (or [Bot Warfare](https://github.com/ineedbots/iw4_bot_warfare)
>   waypoints, if you add them).
> - **Settings menu** (RB + Start), in the style of the Skate 3 iPad port:
>   resolution scale, frame rate, aspect ratio, anti-aliasing, field of view,
>   bots, and cheats — max rank, prestige, unlock everything.
> - **No stutter** — shader pipelines compiled off the draw and kept between
>   launches.
>
> Building, installing the game and iPad notes: [ios/README.md](ios/README.md).
> The Skate 3 iPad port is [vrcnx/skate3recomp-ios](https://github.com/vrcnx/skate3recomp-ios).
>
> ![The settings menu over the multiplayer menu](docs/images/settings-menu.jpg)

![The multiplayer menu, running in a window](docs/images/multiplayer-menu.png)

**[Download the latest release](../../releases/latest)**

## Playing online safely

Play online only with people you trust. The game's 2009 network code is
unchanged, and it has known security bugs.

- There is no public matchmaking, so a stranger cannot join your game.
- **Steam** build: only your Steam friends can join, and the game ignores
  traffic from anyone who is not in your lobby.
- **LAN** build: anyone on the same network can reach the game.

## Features

- Campaign and multiplayer
- Private matches and system link, online with friends:
  - **Steam** build: invite friends through Steam, no port to open
  - **LAN** build: for players without Steam, on the same network
- 60 fps, native MSAA, any window size or fullscreen, drawn at 720p, 1440p or 4K
- Xbox 360-style controller, with rumble

Not supported: public matchmaking and ranked playlists (they needed
Activision's servers). Special Ops is untested.

## Requirements

- An ISO of the Xbox 360 disc, version 1.0.557 (USA/Europe). The launcher
  checks it, and downloads title update 6 itself.
- Linux or Windows, 64-bit
- A Vulkan 1.2 GPU
- 8 GB of disk space
- A controller (the keyboard only covers the menus)

## Install

1. Download `steam` or `lan` for your system from the
   [releases](../../releases/latest), and extract it anywhere.
2. Start `mw2-launcher` and choose INSTALL GAME. It asks for your ISO, copies
   the game files into `game/` beside it and applies title update 6.
3. PLAY CAMPAIGN and PLAY MULTIPLAYER start the game; so do `mw2-sp` and
   `mw2-mp` directly.

From a terminal: `./mw2-launcher --install path/to/game.iso` (an extracted
disc folder works too). If the update can't be downloaded, the launcher says
where to get it and takes the file (`--update <file>`).

The launcher also has PROFILES (set the multiplayer rank and prestige, unlock
everything, open the campaign's and Special Ops' missions), GRAPHICS (the
RESOLUTION the game draws at: 720p as on the console, 1440p or 4K, which need
a faster graphics card; the FPS LIMIT: 60 as on the console, or more; the FOV:
65 as on the console, up to 120) and CHECK FOR UPDATES, which installs a newer release
over this one.

Something wrong? REPORT A BUG runs the game once with its log kept, then
writes a report file and opens a new issue with your system's description
filled in. Describe what happened, drag the file in, and submit.

Saves go in `saves/` beside the executables.

## Play

| key | |
|---|---|
| `F8` | fullscreen |
| `F6` | invite friends (Steam) |
| arrows, `Enter`, `Esc` | d-pad, Start, Back |
| `Z` `X` `C` `V`, `Q` `E` | A B X Y, bumpers |

**Online.** Everyone runs `mw2-mp` from the same build.

- **Steam**: with Steam running, the game shows as *Spacewar*. Without it, the
  `steam` download plays as the `lan` one does, with a rank of its own. Host a
  PLAY ONLINE → PRIVATE MATCH, invite from Steam's friend list (or `F6` if you
  added `mw2-mp` to Steam as a non-Steam game). The friend accepts while their
  game is running.
- **LAN**: SYSTEM LINK finds games on the network by itself. For private
  matches, the lobby's "Invite friends" invites everyone on the network; start
  the others with `MW2_LAN_ACCEPT=1`.

**Players.** You are a profile, made the first time you play and named after
your login; your rank is kept under it. The launcher's PROFILES screen renames
it, and puts another profile in your place. On Steam other players see your
Steam name. A second, third or fourth controller signs in on the game's
sign-in screen, which opens where the game asks for it (SIGN IN PROFILE in
split screen, SYSTEM LINK) or with the Guide button (or Back and Start
together): choose a profile, which keeps its own rank and settings, or make a
new one. Two copies of `mw2-mp` on one PC can play a SYSTEM LINK match, each with
the controller that chose SYSTEM LINK in it.

**Settings**: `MW2_FULLSCREEN=1`, `MW2_SCALE=<2 or 3>` (what RESOLUTION
sets), `MW2_FPS_LIMIT=<n>` (what FPS LIMIT sets; 0 is no limit), `MW2_FOV=<65 to 120>` (what FOV sets), `MW2_MSAA=<n>` or `MW2_NO_MSAA=1`, `MW2_NO_AUDIO=1`. Set them as
environment variables, or keep them in a file named `.env` beside the
executables, one per line.

**Bug reports**: run with `MW2_LOG_FILE=mw2.log` and attach the file.

## Developers

Building, the source layout and how the runtime works:
[docs/building.md](docs/building.md), [docs/runtime.md](docs/runtime.md),
[docs/switches.md](docs/switches.md), and the rest of [docs/](docs/).

## License

[GPL-3.0-only](LICENSE) (`SPDX-License-Identifier: GPL-3.0-only`). It covers this
project's own code: the runtime, tools, patches and build files. It grants
nothing for the game: Activision's code and data, and the C++ generated from
the game's executables, are not part of this repository and not under this
license.

No game code or data is included; the builds only run with files from your
own disc. Not affiliated with Activision, Infinity Ward or Microsoft.
